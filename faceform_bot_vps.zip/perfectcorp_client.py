import os
import requests
import json
import logging
import base64
from io import BytesIO

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class PerfectCorpClient:
    """Client for PerfectCorp YCE API for virtual try-on"""
    
    def __init__(self):
        """Initialize the PerfectCorp client with API key from environment variables"""
        self.api_key = os.environ.get("PERFECTCORP_YCE_API_KEY")
        if not self.api_key:
            logger.error("PerfectCorp YCE API key not found in environment variables")
            raise ValueError("Missing PerfectCorp YCE API key")
        
        # Use the official API endpoint based on the example
        self.base_url = "https://yce-api-01.perfectcorp.com/s2s/v1.0"
        
        # Verify API key is valid
        logger.info(f"Initializing PerfectCorp YCE client with endpoint: {self.base_url}")
        
        try:
            self._validate_api_key()
            logger.info(f"PerfectCorp YCE API key validated with endpoint: {self.base_url}")
        except requests.exceptions.RequestException as e:
            logger.error(f"Failed to connect to PerfectCorp API: {e}")
            raise ConnectionError("Cannot connect to PerfectCorp API")
        
    def _validate_api_key(self):
        """Validate the API key by testing a simple request"""
        import random
        
        # Use the Bearer token authentication as shown in the example
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # Для AI Hairstyle Generator используем endpoint проверки лимитов для валидации ключа
        endpoint = f"{self.base_url}/check-limit"
        
        try:
            # Проверяем соединение с API
            logger.info(f"Validating API key with endpoint: {endpoint}")
            response = requests.get(endpoint, headers=headers)
            
            logger.info(f"API response status: {response.status_code}")
            logger.info(f"API response: {response.text}")
            
            # Проверяем валидность API ключа
            if response.status_code == 200:
                # Успешная валидация - ключ действителен
                logger.info("API key validated successfully")
                return
            elif response.status_code == 401:
                logger.error("API key is invalid or expired")
                raise ValueError("Invalid API key: authentication failed")
            else:
                # Пробуем выполнить простой запрос как альтернативный способ проверки
                # Используем минимальный запрос для text-to-image
                request_id = random.randint(10000, 99999)
                
                payload = {
                    "request_id": request_id,
                    "payload": {
                        "actions": [
                            {
                                "id": 0,
                                "params": {
                                    "prompt": "Test connection",
                                    "negative_prompt": "",
                                    "style_group_id": 18213963761051864,
                                    "style_ids": [22205685004925400],
                                    "steps": 1,  # Минимальное значение для быстрой проверки
                                    "cfg_scale": 4,
                                    "seed": [12345],
                                    "width_ratio": 1,
                                    "height_ratio": 1
                                }
                            }
                        ]
                    }
                }
                
                # Используем эндпоинт для запуска задачи без фактического выполнения 
                alt_endpoint = f"{self.base_url}/task/text-to-image"
                logger.info(f"Trying alternative validation with endpoint: {alt_endpoint}")
                
                alt_response = requests.post(alt_endpoint, headers=headers, json=payload)
                
                logger.info(f"Alternative API response status: {alt_response.status_code}")
                logger.info(f"Alternative API response: {alt_response.text}")
                
                # Проверяем результат альтернативной валидации
                if alt_response.status_code in (200, 400):
                    # Если получили 200 (задача создана) или 400 (ошибка валидации),
                    # значит ключ валидный, но есть другие проблемы с запросом
                    logger.info("API key seems valid (received proper response status)")
                    return
                else:
                    # Если получили другой статус, вероятно, ключ недействителен
                    logger.error(f"API key validation failed: {alt_response.status_code}")
                    raise ValueError(f"Invalid API key or service unavailable: {alt_response.status_code}")
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Connection error while validating API key: {e}")
            raise
            
    def get_available_hairstyles(self):
        """Get list of available hairstyle templates from the API"""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # Для новой API не требуется получение списка причесок, так как это модель text-to-image
        # Вместо этого создаем несколько базовых шаблонов для каждой формы лица
        
        # Создаем заглушку заранее определенных стилей
        hairstyles = [
            {
                "id": "style1",
                "name": "Классический боб",
                "description": "Универсальная прическа для всех типов лица"
            },
            {
                "id": "style2",
                "name": "Удлиненное каре",
                "description": "Элегантная прическа, подходящая для овального и квадратного лица"
            },
            {
                "id": "style3",
                "name": "Длинные волнистые волосы",
                "description": "Романтичный образ для круглого и сердцевидного лица"
            },
            {
                "id": "style4",
                "name": "Короткая стрижка пикси",
                "description": "Смелый стиль для овального и ромбовидного лица"
            },
            {
                "id": "style5",
                "name": "Объемные кудри",
                "description": "Роскошный объемный стиль для удлиненного лица"
            }
        ]
        
        logger.info(f"Using {len(hairstyles)} predefined hairstyles")
        return hairstyles
    
    def get_hairstyles_by_face_shape(self, face_shape):
        """
        Get hairstyles recommended for a specific face shape
        
        Args:
            face_shape (str): Face shape (OVAL, ROUND, SQUARE, HEART, OBLONG, DIAMOND)
            
        Returns:
            list: List of hairstyle templates suitable for the face shape
        """
        # Получаем все доступные прически
        all_hairstyles = self.get_available_hairstyles()
        
        # Карта рекомендаций для определенных форм лица
        # Хотя API не предоставляет рекомендации, используем заранее настроенные 
        # рекомендации для разных форм лица
        recommendations = {
            "OVAL": ["style1", "style2", "style4"],  # Овальному лицу подходит почти всё
            "ROUND": ["style2", "style3"],           # Круглому лицу - удлиняющие прически
            "SQUARE": ["style1", "style2", "style5"], # Квадратному - смягчающие углы
            "HEART": ["style3", "style5"],           # Сердцевидному - объемные внизу
            "OBLONG": ["style4", "style5"],          # Удлиненному - объемные по бокам
            "DIAMOND": ["style1", "style4"]          # Ромбовидному - структурированные
        }
        
        # Получаем рекомендуемые ID для этой формы лица
        recommended_ids = recommendations.get(face_shape, ["style1", "style2", "style3"])
        
        # Фильтруем полный список причесок по рекомендациям
        recommended_hairstyles = [h for h in all_hairstyles if h["id"] in recommended_ids]
        
        logger.info(f"Found {len(recommended_hairstyles)} recommended hairstyles for {face_shape} face shape")
        
        # Если нет рекомендаций (что маловероятно), возвращаем всё
        if not recommended_hairstyles:
            return all_hairstyles
            
        return recommended_hairstyles
    
    def apply_hairstyle(self, image_data, hairstyle_id=None):
        """
        Apply a hairstyle to an image using PerfectCorp API
        
        Args:
            image_data (bytes): Image data
            hairstyle_id (str): ID of hairstyle to apply, or None for automatic
            
        Returns:
            bytes: Image with hairstyle applied or None if there's an error
        """
        import random
        import time
        
        # Используем API для text-to-image с указанием типа прически
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        # Получаем стиль на основе hairstyle_id
        style_prompts = {
            "style1": "professional bob haircut, shoulder length",
            "style2": "elegant long bob haircut with layers",
            "style3": "long wavy romantic hairstyle",
            "style4": "short pixie cut, stylish and bold",
            "style5": "voluminous curly hairstyle, medium length"
        }
        
        # Выбираем промпт в зависимости от ID или берем дефолтный
        chosen_prompt = style_prompts.get(str(hairstyle_id) if hairstyle_id else "default", "elegant hairstyle, natural looking")
        
        logger.info(f"Attempting to apply hairstyle using prompt: {chosen_prompt}")
        
        # Реальная реализация с использованием API PerfectCorp для AI Hairstyle Generator
        try:
            # Генерируем уникальный ID запроса
            request_id = random.randint(10000, 99999)
            
            # Конвертируем входное изображение в base64
            base64_image = base64.b64encode(image_data).decode('utf-8')
            
            # Создаем payload для API
            payload = {
                "request_id": request_id,
                "payload": {
                    "actions": [
                        {
                            "id": 0,
                            "params": {
                                "prompt": f"person with {chosen_prompt}, professional portrait, realistic",
                                "negative_prompt": "bad quality, blurry, deformed face, unrealistic, cartoon",
                                "style_group_id": 18213963761051864,  # Hairstyle generator group
                                "style_ids": [22205685004925400],     # Default style
                                "steps": 20,
                                "cfg_scale": 7,                      # Higher value for more prompt adherence
                                "seed": [random.randint(10000, 99999)],  # Random seed for variety
                                "width_ratio": 3,
                                "height_ratio": 4,
                                "reference_image": base64_image       # Use uploaded image as reference
                            }
                        }
                    ]
                }
            }
            
            # Отправляем запрос на создание изображения
            endpoint = f"{self.base_url}/task/text-to-image"
            response = requests.post(endpoint, headers=headers, json=payload)
            
            # Проверяем успешность запроса
            if response.status_code != 200:
                logger.error(f"Failed to apply hairstyle: {response.status_code} - {response.text}")
                return None
                
            # Получаем результат задачи
            result = response.json()
            task_id = result.get("task_id")
            
            if not task_id:
                logger.error(f"No task_id in response: {result}")
                return None
                
            # Ждем завершения задачи с периодическим опросом статуса
            result_endpoint = f"{self.base_url}/task/result?task_id={task_id}"
            
            max_attempts = 10
            wait_time = 3
            
            for attempt in range(max_attempts):
                logger.info(f"Checking task status, attempt {attempt+1}/{max_attempts}")
                
                # Ждем перед каждой проверкой
                time.sleep(wait_time)
                
                # Проверяем статус задачи
                result_response = requests.get(result_endpoint, headers=headers)
                
                if result_response.status_code != 200:
                    logger.error(f"Failed to get task result: {result_response.status_code} - {result_response.text}")
                    continue
                    
                # Парсим результат
                result_data = result_response.json()
                
                # Проверяем, завершена ли задача
                if result_data.get("status") == "completed":
                    # Получаем URL изображения
                    image_urls = result_data.get("result", {}).get("image_urls", [])
                    
                    if not image_urls:
                        logger.error("No image URLs in completed task result")
                        return None
                        
                    # Берем первое изображение
                    image_url = image_urls[0]
                    
                    # Скачиваем изображение
                    img_response = requests.get(image_url)
                    if img_response.status_code != 200:
                        logger.error(f"Failed to download result image: {img_response.status_code}")
                        return None
                        
                    # Возвращаем байты изображения
                    logger.info("Successfully applied hairstyle and downloaded result")
                    return img_response.content
                
                # Если задача все еще выполняется, продолжаем ждать
                elif result_data.get("status") in ["pending", "processing"]:
                    logger.info(f"Task still processing, waiting... Status: {result_data.get('status')}")
                    continue
                    
                # Если задача не удалась, выходим из цикла
                else:
                    logger.error(f"Task failed with status: {result_data.get('status')}")
                    break
            
            logger.error("Max attempts reached waiting for task completion")
            return None
                
        except Exception as e:
            logger.error(f"Error applying hairstyle: {e}")
            
            # Если произошла ошибка, используем заглушку как запасной вариант
            try:
                from PIL import Image, ImageDraw
                import io
                
                # Создаем запасное изображение с информацией об ошибке
                img = Image.new('RGB', (800, 600), color=(255, 255, 255))
                d = ImageDraw.Draw(img)
                
                # Добавляем текст об ошибке
                d.text((50, 50), "Не удалось применить прическу", fill=(0, 0, 0))
                d.text((50, 100), f"Выбранный стиль: {chosen_prompt}", fill=(0, 0, 0))
                d.text((50, 150), f"Ошибка: {str(e)}", fill=(0, 0, 0))
                
                # Сохраняем изображение в буфер
                buffer = io.BytesIO()
                img.save(buffer, format='JPEG')
                buffer.seek(0)
                
                # Возвращаем изображение с информацией об ошибке
                logger.info("Generated fallback error image")
                return buffer.getvalue()
                
            except Exception as fallback_error:
                logger.error(f"Failed to create fallback image: {fallback_error}")
                return None