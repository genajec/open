import logging
import os
import tempfile
import io
import telebot
import cv2
import numpy as np

from config import TELEGRAM_API_TOKEN, BOT_MESSAGES, FACE_SHAPE_CRITERIA
from face_analyzer import FaceAnalyzer
from hairstyle_recommender import HairstyleRecommender

# Enable logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

class FaceShapeBot:
    def __init__(self, use_webhook=False):
        # Создаем экземпляр бота с параметром threaded=False для предотвращения конфликтов
        self.bot = telebot.TeleBot(TELEGRAM_API_TOKEN, threaded=False)
        self.face_analyzer = FaceAnalyzer()
        self.hairstyle_recommender = HairstyleRecommender()
        
        # Сохраняем режим работы (webhook или polling)
        self.use_webhook = use_webhook
        
        # Store user data for hairstyle virtual try-on
        self.user_data = {}
        
        # Регистрация обработчиков сообщений
        @self.bot.message_handler(commands=['start'])
        def handle_start(message):
            self.start(message)
            
        @self.bot.message_handler(commands=['help'])
        def handle_help(message):
            self.help_command(message)
            
        @self.bot.message_handler(commands=['try'])
        def handle_try(message):
            self.try_hairstyle_command(message)
            
        @self.bot.message_handler(commands=['hairstyles'])
        def handle_hairstyles(message):
            self.list_hairstyles_command(message)
            
        @self.bot.message_handler(commands=['reset'])
        def handle_reset(message):
            self.reset_command(message)
            
        @self.bot.message_handler(content_types=['photo'])
        def handle_photo(message):
            self.process_photo(message)
            
        @self.bot.message_handler(content_types=['text'])
        def handle_text(message):
            # Проверяем, не является ли это командой
            if message.text.startswith('/'):
                return
                
            # Check if this is a response to the hairstyle selection prompt
            chat_id = message.chat.id
            if chat_id in self.user_data and self.user_data[chat_id].get('waiting_for_hairstyle_selection'):
                self.apply_selected_hairstyle(message)
                return
                
            self.handle_message(message)
        
    def start(self, message):
        """Send a message when the command /start is issued."""
        chat_id = message.chat.id
        self.bot.send_message(chat_id, BOT_MESSAGES["start"])

    def help_command(self, message):
        """Send a message when the command /help is issued."""
        chat_id = message.chat.id
        self.bot.send_message(chat_id, BOT_MESSAGES["help"])

    def process_photo(self, message):
        """Process the user photo and send face shape analysis with recommendations."""
        chat_id = None
        try:
            chat_id = message.chat.id
            
            # Send processing message
            self.bot.send_message(chat_id, BOT_MESSAGES["processing"])
            
            # Get the largest photo (best quality)
            photos = message.photo
            if not photos:
                self.bot.send_message(chat_id, BOT_MESSAGES["no_face"])
                return
                
            photo = photos[-1]  # Get largest photo
            
            # Download the photo
            file_info = self.bot.get_file(photo.file_id)
            downloaded = self.bot.download_file(file_info.file_path)
            
            # Analyze the face
            face_shape, vis_image_bytes, measurements = self.face_analyzer.analyze_face_shape(downloaded)
            
            if face_shape is None:
                self.bot.send_message(chat_id, BOT_MESSAGES["no_face"])
                return
                
            # Get hairstyle recommendations
            face_shape_description, recommendations = self.hairstyle_recommender.get_recommendations(face_shape)
            
            # Store user data for hairstyle virtual try-on
            # We need to extract landmarks for hairstyle positioning
            try:
                # Convert image bytes to numpy array
                nparr = np.frombuffer(downloaded, np.uint8)
                image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                
                # Convert to RGB for MediaPipe
                image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                
                # Process the image to get facial landmarks
                results = self.face_analyzer.face_mesh.process(image_rgb)
                
                # Extract landmarks if face was detected
                if results.multi_face_landmarks:
                    face_landmarks = results.multi_face_landmarks[0]
                    height, width, _ = image.shape
                    landmarks = []
                    for landmark in face_landmarks.landmark:
                        x, y = int(landmark.x * width), int(landmark.y * height)
                        landmarks.append((x, y))
                        
                    # Store user data for later use with hairstyle try-on
                    if chat_id not in self.user_data:
                        self.user_data[chat_id] = {}
                        
                    self.user_data[chat_id].update({
                        'face_shape': face_shape,
                        'landmarks': landmarks,
                        'image_data': downloaded,
                        'waiting_for_hairstyle_selection': False
                    })
                    
                    logger.info(f"Stored user data for chat_id {chat_id}")
            except Exception as e:
                logger.error(f"Error extracting landmarks: {e}")
                
            # Format the message
            result_message = [
                f"✅ Анализ завершен!",
                f"",
                f"📊 Форма твоего лица: {face_shape_description}",
                f"",
                "💇 Рекомендации по стрижкам:"
            ]
            result_message.extend(recommendations)
            result_message.extend([
                "",
                "🔍 Примерить прическу: /try",
                "📋 Список причесок: /hairstyles"
            ])
            
            # Add some measurements for context (optional)
            if measurements:
                result_message.append("")
                result_message.append("📏 Измерения (технические данные):")
                for key, value in measurements.items():
                    result_message.append(f"- {key}: {value:.2f}")
                    
            # Send the visualization image with facial landmarks
            if vis_image_bytes:
                vis_image_io = io.BytesIO(vis_image_bytes)
                vis_image_io.name = 'face_analysis.jpg'
                self.bot.send_photo(
                    chat_id,
                    vis_image_io,
                    caption="Анализ лицевых точек"
                )
                
            # Send the recommendations
            self.bot.send_message(chat_id, "\n".join(result_message))
            
        except Exception as e:
            logger.error(f"Error processing photo: {e}")
            try:
                if chat_id:
                    self.bot.send_message(chat_id, BOT_MESSAGES["error"])
                else:
                    logger.error("Chat ID is None, can't send error message")
            except:
                logger.error("Failed to send error message to user")

    def handle_message(self, message):
        """Handle non-photo messages."""
        chat_id = message.chat.id
        self.bot.send_message(chat_id, BOT_MESSAGES["non_photo"])

    def try_hairstyle_command(self, message):
        """Handle the /try command to try on hairstyles"""
        chat_id = message.chat.id
        
        # Check if user has submitted a photo before
        if chat_id not in self.user_data or 'face_shape' not in self.user_data[chat_id]:
            self.bot.send_message(chat_id, BOT_MESSAGES["no_photo_yet"])
            return
            
        # Get available hairstyles for the user's face shape
        face_shape = self.user_data[chat_id]['face_shape']
        
        # Get hairstyle names from PerfectCorp API
        available_hairstyles = self.face_analyzer.get_hairstyle_names(face_shape)
        
        if not available_hairstyles:
            self.bot.send_message(chat_id, BOT_MESSAGES["no_hairstyles"])
            return
            
        # Format hairstyle list
        hairstyles_text = [f"{i+1}. {name}" for i, name in enumerate(available_hairstyles)]
        hairstyles_message = "\n".join(hairstyles_text)
        
        # Set user state to waiting for hairstyle selection
        self.user_data[chat_id]['waiting_for_hairstyle_selection'] = True
        self.user_data[chat_id]['available_hairstyles'] = available_hairstyles
        
        # Ask user to select a hairstyle
        self.bot.send_message(chat_id, BOT_MESSAGES["try_hairstyle"] + "\n\n" + hairstyles_message)
        
    def list_hairstyles_command(self, message):
        """Handle the /hairstyles command to list available hairstyles"""
        chat_id = message.chat.id
        
        # Check if user has submitted a photo before
        if chat_id not in self.user_data or 'face_shape' not in self.user_data[chat_id]:
            self.bot.send_message(chat_id, BOT_MESSAGES["no_photo_yet"])
            return
            
        # Get available hairstyles for the user's face shape
        face_shape = self.user_data[chat_id]['face_shape']
        face_shape_description = FACE_SHAPE_CRITERIA[face_shape]["description"]
        
        # Get hairstyle names from PerfectCorp API
        available_hairstyles = self.face_analyzer.get_hairstyle_names(face_shape)
        
        if not available_hairstyles:
            self.bot.send_message(chat_id, BOT_MESSAGES["no_hairstyles"])
            return
            
        # Format hairstyle list
        hairstyles_text = [f"{i+1}. {name}" for i, name in enumerate(available_hairstyles)]
        
        # Create the message
        message_text = [
            f"📋 Доступные прически для {face_shape_description}:",
            "",
            "\n".join(hairstyles_text),
            "",
            "Используйте команду /try для виртуальной примерки"
        ]
        
        # Send the list of hairstyles
        self.bot.send_message(chat_id, "\n".join(message_text))
        
    def apply_selected_hairstyle(self, message):
        """Apply the selected hairstyle to the user's photo"""
        chat_id = message.chat.id
        
        # Reset waiting state
        self.user_data[chat_id]['waiting_for_hairstyle_selection'] = False
        
        try:
            # Parse the hairstyle selection number
            selection = int(message.text.strip())
            available_hairstyles = self.user_data[chat_id]['available_hairstyles']
            
            # Check if selection is valid
            if selection < 1 or selection > len(available_hairstyles):
                self.bot.send_message(chat_id, BOT_MESSAGES["invalid_hairstyle"])
                return
                
            # Get the selected hairstyle index (0-based)
            hairstyle_index = selection - 1
            
            # Apply the hairstyle to the user's photo
            image_data = self.user_data[chat_id]['image_data']
            landmarks = self.user_data[chat_id]['landmarks']
            face_shape = self.user_data[chat_id]['face_shape']
            
            # Process the hairstyle overlay
            result_image_bytes = self.face_analyzer.apply_hairstyle(
                image_data, landmarks, face_shape, hairstyle_index
            )
            
            # Send the result image
            result_image_io = io.BytesIO(result_image_bytes)
            result_image_io.name = 'hairstyle_preview.jpg'
            
            # Send the visualization image with applied hairstyle
            self.bot.send_photo(
                chat_id,
                result_image_io,
                caption=BOT_MESSAGES["hairstyle_applied"]
            )
            
        except ValueError:
            # Not a number
            self.bot.send_message(chat_id, BOT_MESSAGES["invalid_hairstyle"])
            
        except Exception as e:
            logger.error(f"Error applying hairstyle: {e}")
            self.bot.send_message(chat_id, BOT_MESSAGES["error"])
            
    def reset_command(self, message):
        """Reset user data and start fresh"""
        chat_id = message.chat.id
        
        # Clear user data for this chat
        if chat_id in self.user_data:
            self.user_data.pop(chat_id)
            logger.info(f"Reset user data for chat_id {chat_id}")
        
        # Send confirmation message
        reset_message = [
            "✅ Данные сброшены!",
            "",
            "Пожалуйста, отправьте новое фото для анализа формы лица и получения рекомендаций по прическам."
        ]
        
        self.bot.send_message(chat_id, "\n".join(reset_message))
        
    def run(self):
        """Run the bot."""
        logger.info("Starting bot...")
        
        # Предварительно удаляем webhook, чтобы избежать конфликтов
        logger.info("Удаляем webhook для предотвращения конфликтов...")
        try:
            result = self.bot.remove_webhook()
            logger.info(f"Webhook удален: {result}")
        except Exception as e:
            logger.error(f"Ошибка при удалении webhook: {e}")
        
        if not self.use_webhook:
            # Запускаем бота в режиме поллинга
            # Используем короткий интервал для более быстрого ответа
            self.bot.polling(none_stop=True, interval=1)
