from bot import FaceShapeBot
from flask import Flask, jsonify, request
import threading
import os
import time
import logging
import atexit
import telebot

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)

# Глобальные переменные для отслеживания состояния бота
bot_thread = None
face_shape_bot = None
is_bot_running = False

def start_bot():
    """Initialize bot without starting polling"""
    global face_shape_bot
    
    # Make sure we only create one instance
    if face_shape_bot is None:
        logger.info("Creating new bot instance")
        
        # Создаем экземпляр бота в режиме webhook
        face_shape_bot = FaceShapeBot(use_webhook=True)
        
        # Устанавливаем вебхук для бота
        try:
            # Определяем базовый URL для вебхука
            webhook_base_url = os.environ.get("WEBHOOK_URL_BASE", "https://faceform.onrender.com")
            webhook_path = "/webhook"
            webhook_url = webhook_base_url + webhook_path
            
            logger.info(f"Setting up webhook at {webhook_url}")
            
            # Удаляем старый вебхук перед установкой нового
            face_shape_bot.bot.remove_webhook()
            
            # Устанавливаем новый вебхук
            result = face_shape_bot.bot.set_webhook(url=webhook_url)
            logger.info(f"Webhook setup result: {result}")
            
            return True
        except Exception as e:
            logger.error(f"Failed to set webhook: {e}")
            return False
    else:
        logger.info("Bot instance already exists")
        return True

# Функция для очистки ресурсов при выходе
def cleanup_resources():
    global is_bot_running
    logger.info("Shutting down, cleaning up resources...")
    is_bot_running = False

# Регистрация функции очистки ресурсов
atexit.register(cleanup_resources)

@app.route("/")
def index():
    return jsonify({
        "status": "running", 
        "message": "Telegram bot is active. Find it at t.me/Faceform_bot"
    })

@app.route("/health")
def health():
    global bot_thread
    
    if bot_thread is None or not bot_thread.is_alive():
        # Restart the bot if it's not running
        try:
            start_bot()
            status = "restarted"
        except Exception as e:
            logger.error(f"Failed to restart bot: {e}")
            status = "restart_failed"
    else:
        status = "ok"
        
    return jsonify({"status": status})

@app.route("/debug")
def debug():
    """Show system information for debugging"""
    import psutil
    
    memory = psutil.virtual_memory()
    return jsonify({
        "memory_used_percent": memory.percent,
        "memory_available": memory.available,
        "cpu_usage": psutil.cpu_percent(interval=1),
        "bot_instance_exists": face_shape_bot is not None,
        "webhook_mode": face_shape_bot.use_webhook if face_shape_bot else False
    })

@app.route("/webhook", methods=["POST"])
def webhook():
    """Webhook endpoint for Telegram bot updates"""
    if request.headers.get("content-type") == "application/json":
        json_string = request.get_data().decode("utf-8")
        update = telebot.types.Update.de_json(json_string)
        
        if face_shape_bot:
            face_shape_bot.bot.process_new_updates([update])
            return "", 200
        else:
            logger.error("Webhook received, but bot instance does not exist")
            return "", 500
    else:
        return "", 403

# Initialize the bot when app starts
with app.app_context():
    start_bot()

# For running directly with Python (without Gunicorn)
if __name__ == "__main__":
    # Start bot
    start_bot()
    
    # Run the Flask app
    app.run(host="0.0.0.0", port=5000)
