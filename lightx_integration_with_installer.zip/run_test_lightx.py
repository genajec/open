#!/usr/bin/env python3
"""
Скрипт для тестирования работы LightX API в отдельном приложении
"""

import os
import sys
import logging
import telebot
from telebot import types
from lightx_bot_integration import create_standalone_bot

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main():
    """
    Запуск тестового бота для LightX API
    """
    try:
        # Проверяем наличие API-ключа
        if not os.environ.get("LIGHTX_API_KEY"):
            logger.warning("API-ключ LightX не найден в переменных окружения")
            logger.info("Функциональность может быть ограничена")
        
        # Создаем бота и интеграцию
        bot, integration = create_standalone_bot()
        
        # Вывод информации о боте
        bot_info = bot.get_me()
        logger.info(f"Запущен бот: @{bot_info.username} (ID: {bot_info.id})")
        
        # Запускаем бота
        logger.info("Запускаем тестовый бот...")
        bot.polling(none_stop=True)
        
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {str(e)}")

if __name__ == "__main__":
    main()