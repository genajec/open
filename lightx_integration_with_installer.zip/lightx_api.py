#!/usr/bin/env python3
"""
Модуль для работы с LightX API для AI-подбора причесок
Основан на официальной документации LightX API
"""

import os
import json
import base64
import logging
import requests
import time
from typing import Optional, Dict, List, Any, Union

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LightXAPI:
    """
    Клиент для работы с LightX API для генерации причесок с помощью AI
    """
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Инициализация клиента LightX API
        
        Args:
            api_key (str, optional): API-ключ для LightX. Если не указан, 
                                    будет использоваться значение из переменной 
                                    окружения LIGHTX_API_KEY
        """
        self.api_key = api_key or os.environ.get("LIGHTX_API_KEY")
        if not self.api_key:
            logger.warning("API-ключ LightX не найден. Функциональность будет ограничена.")
        
        self.base_url = "https://api.lightxeditor.com"
        
        # Доступные стили причесок в LightX на основе документации
        self.available_styles = [
            "короткий боб",
            "длинные прямые волосы",
            "кудрявые волосы",
            "волнистые волосы",
            "высокий хвост",
            "мужская короткая стрижка",
            "мужская длинная стрижка"
        ]
    
    def is_available(self) -> bool:
        """
        Проверка доступности API
        
        Returns:
            bool: True, если API доступен, иначе False
        """
        return self.api_key is not None
    
    def get_available_styles(self) -> List[str]:
        """
        Получение списка доступных стилей причесок
        
        Returns:
            List[str]: Список стилей
        """
        return self.available_styles
    
    def apply_hairstyle(self, image_data: bytes, hairstyle_name: str) -> Optional[bytes]:
        """
        Применение стиля прически к изображению через прямой вызов AI-hairstyle API
        
        Args:
            image_data (bytes): Байты изображения
            hairstyle_name (str): Название стиля прически
            
        Returns:
            Optional[bytes]: Изображение с примененной прической или None в случае ошибки
        """
        if not self.is_available():
            logger.error("API-ключ LightX не настроен")
            return None
        
        try:
            # Кодируем изображение в base64
            base64_image = base64.b64encode(image_data).decode('utf-8')
            
            # Формируем URL для запроса
            url = f"{self.base_url}/ai-hairstyle"
            
            # Заголовки
            headers = {
                "Content-Type": "application/json",
                "X-API-KEY": self.api_key
            }
            
            # Данные для запроса на основе документации LightX
            data = {
                "image": base64_image,
                "hairstyle": hairstyle_name
            }
            
            # Отправляем запрос
            logger.info(f"Отправляем запрос к LightX API для стиля '{hairstyle_name}'")
            response = requests.post(url, headers=headers, json=data)
            
            # Проверяем статус ответа
            if response.status_code == 200:
                # Обрабатываем успешный ответ
                result = response.json()
                
                if "result" in result and "image" in result["result"]:
                    # Декодируем результат из base64
                    result_image_base64 = result["result"]["image"]
                    result_image_bytes = base64.b64decode(result_image_base64)
                    return result_image_bytes
                else:
                    logger.error(f"Неожиданный формат ответа: {result}")
            else:
                logger.error(f"Ошибка API: {response.status_code} - {response.text}")
            
            return None
            
        except Exception as e:
            logger.exception(f"Ошибка при применении прически: {str(e)}")
            return None
    
    def apply_hairstyle_v2(self, image_data: bytes, hairstyle_name: str) -> Optional[bytes]:
        """
        Альтернативный метод применения стиля прически к изображению через API v2
        с использованием загрузки изображения и проверки статуса заказа
        
        Args:
            image_data (bytes): Байты изображения
            hairstyle_name (str): Название стиля прически
            
        Returns:
            Optional[bytes]: Изображение с примененной прической или None в случае ошибки
        """
        if not self.is_available():
            logger.error("API-ключ LightX не настроен")
            return None
        
        try:
            # Шаг 1: Загрузка изображения и получение URL
            image_url = self._upload_image(image_data)
            if not image_url:
                logger.error("Не удалось загрузить изображение")
                return None
                
            # Шаг 2: Отправка запроса на генерацию прически
            order_id = self._create_hairstyle_order(image_url, hairstyle_name)
            if not order_id:
                logger.error("Не удалось создать заказ на генерацию прически")
                return None
                
            # Шаг 3: Проверка статуса заказа и получение результата
            max_attempts = 5
            attempt = 0
            result_url = None
            
            while attempt < max_attempts:
                status, result = self._check_order_status(order_id)
                
                if status == "active" and result:
                    result_url = result
                    break
                    
                if status == "failed":
                    logger.error("Заказ не удался")
                    return None
                    
                # Ждем 3 секунды перед следующей попыткой
                attempt += 1
                time.sleep(3)
            
            if not result_url:
                logger.error(f"Не удалось получить результат после {max_attempts} попыток")
                return None
                
            # Шаг 4: Загрузка результата
            response = requests.get(result_url)
            if response.status_code == 200:
                return response.content
            else:
                logger.error(f"Не удалось загрузить результат: {response.status_code}")
                return None
                
        except Exception as e:
            logger.exception(f"Ошибка при применении прически v2: {str(e)}")
            return None
    
    def _upload_image(self, image_data: bytes) -> Optional[str]:
        """
        Загрузка изображения на сервер LightX
        
        Args:
            image_data (bytes): Байты изображения
            
        Returns:
            Optional[str]: URL загруженного изображения или None в случае ошибки
        """
        try:
            # Запрос на получение URL для загрузки
            url = f"{self.base_url}/external/api/v2/uploadImageUrl"
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            data = {
                "uploadType": "imageUrl",
                "size": len(image_data),
                "contentType": "image/jpeg"
            }
            
            response = requests.post(url, headers=headers, json=data)
            
            if response.status_code != 200:
                logger.error(f"Ошибка при получении URL для загрузки: {response.status_code} - {response.text}")
                return None
                
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Неверный ответ от API: {result}")
                return None
                
            upload_url = result["body"].get("uploadImage")
            image_url = result["body"].get("imageUrl")
            
            if not upload_url or not image_url:
                logger.error("URL для загрузки или URL изображения отсутствует в ответе")
                return None
                
            # Загрузка изображения по полученному URL
            upload_response = requests.put(
                upload_url, 
                headers={"Content-Type": "image/jpeg"}, 
                data=image_data
            )
            
            if upload_response.status_code != 200:
                logger.error(f"Ошибка при загрузке изображения: {upload_response.status_code}")
                return None
                
            return image_url
            
        except Exception as e:
            logger.exception(f"Ошибка при загрузке изображения: {str(e)}")
            return None
    
    def _create_hairstyle_order(self, image_url: str, hairstyle_name: str) -> Optional[str]:
        """
        Создание заказа на генерацию прически
        
        Args:
            image_url (str): URL изображения
            hairstyle_name (str): Название стиля прически
            
        Returns:
            Optional[str]: ID заказа или None в случае ошибки
        """
        try:
            url = f"{self.base_url}/external/api/v1/hairstyle"
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            data = {
                "imageUrl": image_url,
                "textPrompt": hairstyle_name
            }
            
            response = requests.post(url, headers=headers, json=data)
            
            if response.status_code != 200:
                logger.error(f"Ошибка при создании заказа: {response.status_code} - {response.text}")
                return None
                
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Неверный ответ от API: {result}")
                return None
                
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("ID заказа отсутствует в ответе")
                return None
                
            return order_id
            
        except Exception as e:
            logger.exception(f"Ошибка при создании заказа: {str(e)}")
            return None
    
    def _check_order_status(self, order_id: str) -> tuple[str, Optional[str]]:
        """
        Проверка статуса заказа
        
        Args:
            order_id (str): ID заказа
            
        Returns:
            tuple: (статус, URL результата) или (статус, None) в случае ошибки
        """
        try:
            url = f"{self.base_url}/external/api/v1/order-status"
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            data = {
                "orderId": order_id
            }
            
            response = requests.post(url, headers=headers, json=data)
            
            if response.status_code != 200:
                logger.error(f"Ошибка при проверке статуса: {response.status_code} - {response.text}")
                return "failed", None
                
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Неверный ответ от API: {result}")
                return "failed", None
                
            status = result["body"].get("status", "init")
            output = result["body"].get("output") if status == "active" else None
            
            return status, output
            
        except Exception as e:
            logger.exception(f"Ошибка при проверке статуса: {str(e)}")
            return "failed", None
    
    def apply_hairstyle_with_retry(
        self, 
        image_data: bytes, 
        hairstyle_name: str, 
        max_retries: int = 3, 
        retry_delay: int = 2,
        use_v2: bool = False
    ) -> Optional[bytes]:
        """
        Применение стиля прически с повторными попытками в случае ошибки
        
        Args:
            image_data (bytes): Байты изображения
            hairstyle_name (str): Название стиля прически
            max_retries (int): Максимальное количество попыток
            retry_delay (int): Задержка между попытками в секундах
            use_v2 (bool): Использовать ли API v2 вместо прямого вызова
            
        Returns:
            Optional[bytes]: Изображение с примененной прической или None в случае ошибки
        """
        for attempt in range(max_retries):
            try:
                if use_v2:
                    result = self.apply_hairstyle_v2(image_data, hairstyle_name)
                else:
                    result = self.apply_hairstyle(image_data, hairstyle_name)
                    
                if result:
                    return result
                
                logger.warning(f"Попытка {attempt+1}/{max_retries} не удалась")
            except Exception as e:
                logger.warning(f"Попытка {attempt+1}/{max_retries} не удалась: {str(e)}")
            
            # Ждем перед следующей попыткой
            if attempt < max_retries - 1:
                time.sleep(retry_delay)
        
        logger.error(f"Все {max_retries} попыток применения прически не удались")
        return None