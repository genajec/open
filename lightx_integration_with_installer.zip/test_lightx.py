#!/usr/bin/env python3
"""
Скрипт для тестирования интеграции с LightX API для генерации причесок
"""

import os
import sys
import logging
import base64
from lightx_api import LightXAPI

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_hairstyle_generation(image_path, hairstyle_name, use_v2=False):
    """
    Тестирование генерации прически с помощью LightX API
    
    Args:
        image_path (str): Путь к файлу изображения
        hairstyle_name (str): Название стиля прически
        use_v2 (bool): Использовать ли API v2
        
    Returns:
        bool: True если тест прошел успешно, иначе False
    """
    # Инициализируем API клиент
    api = LightXAPI()
    
    if not api.is_available():
        logger.error("API-ключ LightX не настроен")
        return False
    
    # Загружаем изображение
    try:
        with open(image_path, "rb") as img_file:
            image_data = img_file.read()
    except Exception as e:
        logger.error(f"Ошибка при чтении файла {image_path}: {str(e)}")
        return False
    
    # Получаем доступные стили причесок
    styles = api.get_available_styles()
    logger.info(f"Доступные стили причесок: {styles}")
    
    # Проверяем, существует ли запрошенный стиль
    if hairstyle_name not in styles:
        nearest_style = None
        for style in styles:
            if hairstyle_name.lower() in style.lower():
                nearest_style = style
                break
        
        if nearest_style:
            logger.warning(f"Стиль '{hairstyle_name}' не найден, используем ближайший: '{nearest_style}'")
            hairstyle_name = nearest_style
        else:
            logger.error(f"Стиль '{hairstyle_name}' не найден в списке доступных стилей")
            logger.info(f"Используем первый доступный стиль: '{styles[0]}'")
            hairstyle_name = styles[0]
    
    # Применяем стиль прически
    logger.info(f"Применяем стиль '{hairstyle_name}' к изображению {image_path}")
    
    if use_v2:
        logger.info("Используем API v2")
        result = api.apply_hairstyle_v2(image_data, hairstyle_name)
    else:
        logger.info("Используем прямой вызов API")
        result = api.apply_hairstyle_with_retry(image_data, hairstyle_name)
    
    if result:
        # Сохраняем результат
        output_path = f"{os.path.splitext(image_path)[0]}_hairstyle_{hairstyle_name.replace(' ', '_')}.jpg"
        try:
            with open(output_path, "wb") as out_file:
                out_file.write(result)
            logger.info(f"Результат сохранен в {output_path}")
            return True
        except Exception as e:
            logger.error(f"Ошибка при сохранении результата: {str(e)}")
            return False
    else:
        logger.error("Не удалось применить стиль прически")
        return False

def show_available_styles():
    """
    Вывод доступных стилей причесок
    """
    api = LightXAPI()
    styles = api.get_available_styles()
    
    print("Доступные стили причесок:")
    for i, style in enumerate(styles, 1):
        print(f"{i}. {style}")

def main():
    """
    Основная функция для запуска тестирования
    """
    # Проверяем аргументы командной строки
    if len(sys.argv) < 2:
        print("Использование:")
        print("  python test_lightx.py <путь_к_изображению> [стиль_прически] [--v2]")
        print("  python test_lightx.py --styles  # показать доступные стили")
        print("")
        print("Примеры:")
        print("  python test_lightx.py demo_base_face.jpg \"короткий боб\"")
        print("  python test_lightx.py demo_base_face.jpg \"волнистые волосы\" --v2")
        return
    
    # Проверяем параметр --styles
    if sys.argv[1] == "--styles":
        show_available_styles()
        return
    
    # Получаем аргументы
    image_path = sys.argv[1]
    
    # Проверяем существование файла
    if not os.path.exists(image_path):
        logger.error(f"Файл {image_path} не найден")
        return
    
    # Получаем стиль прически (если указан)
    hairstyle_name = "короткий боб"  # стиль по умолчанию
    if len(sys.argv) > 2 and not sys.argv[2].startswith("--"):
        hairstyle_name = sys.argv[2]
    
    # Проверяем использование API v2
    use_v2 = "--v2" in sys.argv
    
    # Запускаем тест
    success = test_hairstyle_generation(image_path, hairstyle_name, use_v2)
    
    if success:
        print("Тест успешно завершен!")
    else:
        print("Тест завершился с ошибкой.")

if __name__ == "__main__":
    main()