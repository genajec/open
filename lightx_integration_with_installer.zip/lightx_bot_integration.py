#!/usr/bin/env python3
"""
Модуль для интеграции LightX API с Telegram ботом для генерации причесок
"""

import os
import telebot
import logging
import tempfile
from telebot import types
from typing import Optional, Dict, List, Any, Callable
from lightx_api import LightXAPI

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LightXBotIntegration:
    """
    Класс для интеграции LightX API с Telegram ботом
    """
    
    def __init__(self, bot, user_data_storage=None):
        """
        Инициализация интеграции
        
        Args:
            bot: Экземпляр telebot.TeleBot
            user_data_storage: Хранилище данных пользователей (словарь или объект с подобным интерфейсом)
        """
        self.bot = bot
        self.api = LightXAPI()
        
        # Используем предоставленное хранилище или создаем новое
        self.user_data = user_data_storage if user_data_storage is not None else {}
        
        # Регистрируем обработчики событий
        self._register_handlers()
    
    def _register_handlers(self):
        """
        Регистрация обработчиков сообщений и callback-запросов
        """
        # Обработчик команды /aistyle
        @self.bot.message_handler(commands=['aistyle'])
        def handle_aistyle_command(message):
            self.handle_aistyle_command(message)
        
        # Обработчик callback-запросов для выбора стиля
        @self.bot.callback_query_handler(func=lambda call: call.data.startswith('lightx_style_'))
        def handle_lightx_style_selection(call):
            self.handle_style_selection(call)
    
    def handle_aistyle_command(self, message):
        """
        Обработка команды /aistyle
        
        Args:
            message: Сообщение от пользователя
        """
        user_id = message.from_user.id
        
        # Проверяем, есть ли у пользователя загруженное фото
        if user_id not in self.user_data or 'image_data' not in self.user_data[user_id]:
            self.bot.send_message(
                user_id, 
                "Пожалуйста, сначала загрузите фотографию."
            )
            return
        
        # Проверяем, доступен ли LightX API
        if not self.api.is_available():
            self.bot.send_message(
                user_id, 
                "Функция AI-подбора прически временно недоступна. "
                "Попробуйте позже или свяжитесь с администратором."
            )
            return
        
        # Отправляем клавиатуру с выбором стиля прически
        self.send_style_selection(user_id)
    
    def send_style_selection(self, user_id):
        """
        Отправка клавиатуры с выбором стиля прически
        
        Args:
            user_id: ID пользователя
        """
        # Получаем доступные стили причесок
        styles = self.api.get_available_styles()
        
        # Создаем клавиатуру с вариантами причесок
        markup = types.InlineKeyboardMarkup(row_width=2)
        buttons = []
        
        for i, style in enumerate(styles):
            # Добавляем кнопки для каждого стиля
            button_text = style
            callback_data = f"lightx_style_{i}"
            buttons.append(types.InlineKeyboardButton(button_text, callback_data=callback_data))
        
        # Добавляем кнопки в разметку
        markup.add(*buttons)
        
        # Отправляем сообщение с выбором прически
        self.bot.send_message(
            user_id,
            "Выберите стиль прически для AI-генерации:",
            reply_markup=markup
        )
    
    def handle_style_selection(self, call):
        """
        Обработка выбора стиля прически
        
        Args:
            call: Callback-запрос от пользователя
        """
        try:
            # Извлекаем индекс выбранного стиля из callback_data
            style_index = int(call.data.split('_')[-1])
            selected_style = self.api.get_available_styles()[style_index]
            
            # Получаем ID пользователя
            user_id = call.from_user.id
            
            # Проверяем, есть ли у пользователя загруженное фото
            if user_id not in self.user_data or 'image_data' not in self.user_data[user_id]:
                self.bot.send_message(
                    call.message.chat.id, 
                    "Данные изображения не найдены. Пожалуйста, загрузите фотографию снова."
                )
                return
            
            # Отправляем сообщение о начале обработки
            processing_message = self.bot.send_message(
                call.message.chat.id,
                f"Применяем стиль '{selected_style}'...\nЭто может занять до 30 секунд."
            )
            
            # Получаем данные изображения
            image_data = self.user_data[user_id]['image_data']
            
            # Применяем выбранный стиль к изображению
            result_image = self.api.apply_hairstyle_with_retry(
                image_data, selected_style
            )
            
            if result_image:
                # Отправляем результат
                self.bot.send_photo(
                    call.message.chat.id,
                    result_image,
                    caption=f"Результат AI-стилизации: {selected_style}"
                )
            else:
                # Отправляем сообщение об ошибке
                self.bot.send_message(
                    call.message.chat.id,
                    "К сожалению, не удалось применить выбранный стиль. Пожалуйста, попробуйте другой стиль или другое фото."
                )
            
            # Удаляем сообщение о процессе обработки
            try:
                self.bot.delete_message(call.message.chat.id, processing_message.message_id)
            except Exception as e:
                logger.warning(f"Не удалось удалить сообщение о процессе обработки: {str(e)}")
            
        except Exception as e:
            logger.error(f"Ошибка при обработке выбора стиля: {str(e)}")
            self.bot.send_message(
                call.message.chat.id,
                f"Произошла ошибка при обработке стиля: {str(e)}"
            )

def create_standalone_bot(token=None):
    """
    Создать отдельного бота для тестирования интеграции
    
    Args:
        token: Токен Telegram бота
        
    Returns:
        tuple: (bot, integration)
    """
    # Получаем токен из переменных окружения, если не указан
    if not token:
        token = os.environ.get('BOT_TOKEN')
        if not token:
            # Попытка импортировать из config.py
            try:
                from config import BOT_TOKEN
                token = BOT_TOKEN
            except:
                raise ValueError("Токен бота не найден. Укажите его явно или добавьте в переменные окружения.")
    
    # Создаем бота
    bot = telebot.TeleBot(token)
    
    # Создаем интеграцию
    integration = LightXBotIntegration(bot)
    
    # Добавляем базовые обработчики
    @bot.message_handler(commands=['start', 'help'])
    def handle_start_help(message):
        bot.send_message(
            message.chat.id,
            "Привет! Этот бот демонстрирует работу LightX API для подбора причесок.\n"
            "Отправьте мне фотографию, и я предложу выбрать стиль прически."
        )
    
    @bot.message_handler(content_types=['photo'])
    def handle_photo(message):
        # Получаем файл с максимальным разрешением
        file_id = message.photo[-1].file_id
        file_info = bot.get_file(file_id)
        file_data = bot.download_file(file_info.file_path)
        
        # Сохраняем данные изображения
        user_id = message.from_user.id
        if user_id not in integration.user_data:
            integration.user_data[user_id] = {}
        
        integration.user_data[user_id]['image_data'] = file_data
        
        # Отправляем сообщение
        bot.send_message(
            message.chat.id,
            "Фотография получена! Используйте команду /aistyle для выбора стиля прически."
        )
    
    return bot, integration

def main():
    """
    Функция для запуска отдельного бота
    """
    # Создаем бота и интеграцию
    bot, _ = create_standalone_bot()
    
    # Запускаем бота
    logger.info("Запускаем бота...")
    try:
        bot.polling(none_stop=True)
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {str(e)}")

if __name__ == "__main__":
    main()