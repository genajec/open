#!/usr/bin/env python
"""
Скрипт для тестирования функциональности автоматического переключения API ключей LightX
"""

import os
import logging
import argparse
from lightx_client import LightXClient
from dotenv import load_dotenv

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def setup_client():
    """
    Инициализирует и возвращает клиент LightX API
    
    Returns:
        LightXClient: Инициализированный клиент
    """
    # Загружаем переменные окружения
    load_dotenv()
    
    # Проверяем наличие основного API ключа
    if not os.environ.get("LIGHTX_API_KEY"):
        logger.error("Основной API ключ (LIGHTX_API_KEY) не найден в переменных окружения")
        return None
    
    # Проверяем наличие резервных API ключей
    backup_keys_found = 0
    for i in range(1, 4):
        if os.environ.get(f"LIGHTX_API_KEY_BACKUP_{i}"):
            backup_keys_found += 1
    
    logger.info(f"Найдено {backup_keys_found} резервных API ключей")
    
    # Создаем клиент
    try:
        client = LightXClient()
        logger.info("Клиент LightX API успешно инициализирован")
        return client
    except Exception as e:
        logger.error(f"Ошибка при инициализации клиента LightX API: {e}")
        return None

def test_force_key_rotation(client):
    """
    Тестирует принудительное переключение API ключей
    
    Args:
        client (LightXClient): Клиент LightX API
    """
    logger.info("Начинаем тест принудительного переключения API ключей")
    
    initial_key = client.api_key
    logger.info(f"Исходный API ключ: {initial_key[:8]}...{initial_key[-8:]}")
    
    # Выводим информацию о резервных ключах
    logger.info(f"Доступно резервных ключей: {len(client.backup_api_keys)}")
    
    # Пробуем переключиться на следующий ключ
    if client.switch_to_next_api_key():
        new_key = client.api_key
        logger.info(f"Успешно переключились на следующий ключ: {new_key[:8]}...{new_key[-8:]}")
        
        # Проверяем, что ключ изменился
        if new_key != initial_key:
            logger.info("Тест пройден: API ключ успешно изменился")
        else:
            logger.error("Тест не пройден: API ключ не изменился")
    else:
        logger.error("Тест не пройден: не удалось переключиться на следующий ключ")
    
    logger.info(f"Осталось доступных резервных ключей: {len(client.backup_api_keys)}")
    
    # Пробуем вернуться на исходный ключ
    while client.api_key != initial_key:
        if client.switch_to_next_api_key():
            logger.info(f"Переключились на ключ: {client.api_key[:8]}...{client.api_key[-8:]}")
        else:
            logger.error("Не удалось вернуться к исходному ключу")
            break

def test_image_upload_with_rotation(client, image_path):
    """
    Тестирует загрузку изображения с автоматическим переключением API ключей при ошибке
    
    Args:
        client (LightXClient): Клиент LightX API
        image_path (str): Путь к тестовому изображению
    """
    logger.info(f"Начинаем тест загрузки изображения с автоматическим переключением API ключей")
    
    # Проверяем наличие файла изображения
    if not os.path.exists(image_path):
        logger.error(f"Файл изображения {image_path} не найден")
        return
    
    # Читаем изображение
    try:
        with open(image_path, "rb") as f:
            image_data = f.read()
            logger.info(f"Успешно прочитано изображение {image_path}, размер: {len(image_data)} байт")
    except Exception as e:
        logger.error(f"Ошибка при чтении изображения: {e}")
        return
    
    # Запоминаем исходный ключ
    initial_key = client.api_key
    logger.info(f"Исходный API ключ: {initial_key[:8]}...{initial_key[-8:]}")
    
    # Вызываем метод загрузки изображения
    logger.info("Загружаем изображение...")
    image_url = client.upload_image(image_data)
    
    # Проверяем результат
    if image_url:
        logger.info(f"Успешно загружено изображение. URL: {image_url}")
        
        # Проверяем, изменился ли ключ
        if client.api_key != initial_key:
            logger.info(f"Произошло автоматическое переключение на новый ключ: {client.api_key[:8]}...{client.api_key[-8:]}")
        else:
            logger.info("API ключ не изменился (загрузка выполнена с исходным ключом)")
    else:
        logger.error("Не удалось загрузить изображение")
        
        # Проверяем, изменился ли ключ
        if client.api_key != initial_key:
            logger.info(f"Произошло автоматическое переключение на новый ключ: {client.api_key[:8]}...{client.api_key[-8:]}")
        else:
            logger.error("API ключ не изменился, несмотря на ошибку загрузки")

def test_hairstyle_generation_with_rotation(client, image_path, prompt):
    """
    Тестирует генерацию прически с автоматическим переключением API ключей при ошибке
    
    Args:
        client (LightXClient): Клиент LightX API
        image_path (str): Путь к тестовому изображению
        prompt (str): Текстовый запрос для генерации прически
    """
    logger.info(f"Начинаем тест генерации прически с автоматическим переключением API ключей")
    
    # Проверяем наличие файла изображения
    if not os.path.exists(image_path):
        logger.error(f"Файл изображения {image_path} не найден")
        return
    
    # Читаем изображение
    try:
        with open(image_path, "rb") as f:
            image_data = f.read()
            logger.info(f"Успешно прочитано изображение {image_path}, размер: {len(image_data)} байт")
    except Exception as e:
        logger.error(f"Ошибка при чтении изображения: {e}")
        return
    
    # Запоминаем исходный ключ
    initial_key = client.api_key
    logger.info(f"Исходный API ключ: {initial_key[:8]}...{initial_key[-8:]}")
    
    # Вызываем метод генерации прически
    logger.info(f"Генерируем прическу с запросом: {prompt}")
    result_image = client.apply_hairstyle(image_data, prompt)
    
    # Проверяем результат
    if result_image:
        logger.info(f"Успешно сгенерирована прическа. Размер результата: {len(result_image)} байт")
        
        # Сохраняем результат
        try:
            output_path = "generated_hairstyle_test.jpg"
            with open(output_path, "wb") as f:
                f.write(result_image)
            logger.info(f"Результат сохранен в файл {output_path}")
        except Exception as e:
            logger.error(f"Ошибка при сохранении результата: {e}")
        
        # Проверяем, изменился ли ключ
        if client.api_key != initial_key:
            logger.info(f"Произошло автоматическое переключение на новый ключ: {client.api_key[:8]}...{client.api_key[-8:]}")
        else:
            logger.info("API ключ не изменился (генерация выполнена с исходным ключом)")
    else:
        logger.error("Не удалось сгенерировать прическу")
        
        # Проверяем, изменился ли ключ
        if client.api_key != initial_key:
            logger.info(f"Произошло автоматическое переключение на новый ключ: {client.api_key[:8]}...{client.api_key[-8:]}")
        else:
            logger.error("API ключ не изменился, несмотря на ошибку генерации")

def main():
    """
    Основная функция скрипта
    """
    # Парсим аргументы командной строки
    parser = argparse.ArgumentParser(description="Тестирование функциональности автоматического переключения API ключей LightX")
    parser.add_argument("--test-type", choices=["force-rotation", "upload", "hairstyle"], 
                        default="force-rotation", help="Тип теста для выполнения")
    parser.add_argument("--image", default="demo_base_face.jpg", 
                        help="Путь к тестовому изображению для тестов загрузки и генерации")
    parser.add_argument("--prompt", default="короткие черные волосы", 
                        help="Текстовый запрос для теста генерации прически")
    
    args = parser.parse_args()
    
    # Инициализируем клиент
    client = setup_client()
    if not client:
        logger.error("Не удалось инициализировать клиент LightX API. Прерываем выполнение тестов.")
        return
    
    # Выполняем тест в зависимости от указанного типа
    if args.test_type == "force-rotation":
        test_force_key_rotation(client)
    elif args.test_type == "upload":
        test_image_upload_with_rotation(client, args.image)
    elif args.test_type == "hairstyle":
        test_hairstyle_generation_with_rotation(client, args.image, args.prompt)
    else:
        logger.error(f"Неизвестный тип теста: {args.test_type}")

if __name__ == "__main__":
    main()