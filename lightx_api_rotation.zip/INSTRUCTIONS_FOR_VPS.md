# Инструкция по установке на VPS

## Требования к серверу
- Ubuntu 24.04 LTS или выше
- Python 3.8+ 
- 2 ГБ RAM (минимум)
- 10 ГБ свободного места на диске

## Подготовка сервера

1. **Обновление системы и установка зависимостей**:

```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y python3-pip python3-venv python3-dev git zip unzip supervisor nginx
```

2. **Копирование файлов на сервер**:

Вариант 1: Клонирование из репозитория
```bash
git clone https://github.com/ваш-репозиторий/faceform_bot.git
cd faceform_bot
```

Вариант 2: Загрузка архива через SCP (с локального компьютера)
```bash
scp lightx_api_rotation.zip Facedorm@ваш_сервер:~/
```

3. **Распаковка архива на сервере**:

```bash
cd ~
mkdir -p faceform_bot_api_rotation
unzip lightx_api_rotation.zip -d faceform_bot_api_rotation
```

4. **Настройка переменных окружения**:

```bash
cd faceform_bot_api_rotation
cp .env.api_rotation .env
nano .env  # Отредактируйте при необходимости
```

## Настройка среды Python

1. **Создание виртуального окружения**:

```bash
cd ~/faceform_bot
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install python-dotenv requests
```

2. **Установка всех зависимостей бота** (если требуется полная установка):

```bash
pip install -r requirements.txt
```

## Настройка запуска бота через Supervisor

1. **Создание конфигурации Supervisor**:

```bash
sudo nano /etc/supervisor/conf.d/faceform_bot.conf
```

Содержимое файла:
```
[program:faceform_bot]
command=/home/Facedorm/faceform_bot/venv/bin/python /home/Facedorm/faceform_bot/run_polling.py
directory=/home/Facedorm/faceform_bot
user=Facedorm
autostart=true
autorestart=true
stderr_logfile=/home/Facedorm/faceform_bot/logs/bot.err.log
stdout_logfile=/home/Facedorm/faceform_bot/logs/bot.out.log
environment=
    PATH="/home/Facedorm/faceform_bot/venv/bin",
    PYTHONPATH="/home/Facedorm/faceform_bot"
```

2. **Создание директории для логов**:

```bash
mkdir -p /home/Facedorm/faceform_bot/logs
```

3. **Активация и запуск сервиса**:

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start faceform_bot
```

## Проверка статуса

Проверьте, что бот запущен и работает:

```bash
sudo supervisorctl status faceform_bot
```

Проверьте работу API ключей:

```bash
cd /home/Facedorm/faceform_bot
source venv/bin/activate
python check_lightx_api_key.py --all --method upload
```

## Настройка регулярного мониторинга API ключей

Добавьте cron-задачу для регулярной проверки статуса API ключей:

```bash
crontab -e
```

Добавьте строку:
```
0 8 * * * cd /home/Facedorm/faceform_bot && source venv/bin/activate && python check_lightx_api_key.py --all > /home/Facedorm/api_keys_report.txt 2>&1
```

## Обновление системы ротации API ключей

Если вы хотите обновить только компоненты ротации API ключей:

```bash
cp ~/faceform_bot_api_rotation/lightx_client.py ~/faceform_bot/
cp ~/faceform_bot_api_rotation/check_lightx_api_key.py ~/faceform_bot/
cp ~/faceform_bot_api_rotation/test_api_key_rotation.py ~/faceform_bot/
```

Перезапустите бота:
```bash
sudo supervisorctl restart faceform_bot
```

## Устранение неполадок

1. **Бот не запускается**: Проверьте логи
   ```bash
   tail -f /home/Facedorm/faceform_bot/logs/bot.err.log
   ```

2. **Проблемы с API ключами**: Проверьте их статус
   ```bash
   cd /home/Facedorm/faceform_bot
   source venv/bin/activate
   python check_lightx_api_key.py --all --method upload
   ```

3. **Зависание или остановка бота**: Перезапустите сервис
   ```bash
   sudo supervisorctl restart faceform_bot
   ```