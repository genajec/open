#!/usr/bin/env python
"""
Скрипт для проверки состояния API ключей LightX и отображения доступных кредитов
"""

import os
import sys
import requests
import logging
import argparse
from datetime import datetime
from dotenv import load_dotenv

# Настраиваем логирование
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def check_api_key(api_key, test_upload=False):
    """
    Проверяет статус API ключа LightX и возвращает информацию о доступных кредитах
    
    Args:
        api_key (str): API ключ для проверки
        test_upload (bool): Если True, проверяет ключ путем запроса URL для загрузки изображения
        
    Returns:
        dict: Информация о статусе ключа или None в случае ошибки
    """
    if not api_key:
        logger.error("API ключ не указан")
        return None
        
    logger.info(f"Проверяем статус API ключа: {api_key[:8]}...{api_key[-8:]}")
    
    # Если выбран тест через загрузку, используем другой endpoint
    if test_upload:
        return check_api_key_via_upload(api_key)
    
    # Endpoint для проверки статуса API ключа (информация о кредитах)
    url = "https://api.sdk.lightx.ai/v1/users/credits"
    
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key
    }
    
    try:
        # Отправляем запрос
        response = requests.get(url, headers=headers)
        logger.info(f"Получен ответ API со статусом: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            logger.info(f"Успешно получена информация о ключе: {result}")
            return result
        elif response.status_code == 403:
            logger.error("Доступ запрещен - кредиты исчерпаны или ключ недействителен")
            return {"status": "FORBIDDEN", "statusCode": 403, "message": "Access forbidden"}
        else:
            logger.error(f"Ошибка при проверке статуса API ключа: {response.status_code} - {response.text}")
            return None
    
    except Exception as e:
        logger.error(f"Исключение при проверке статуса API ключа: {e}")
        return None

def check_api_key_via_upload(api_key):
    """
    Проверяет статус API ключа LightX путем запроса URL для загрузки изображения
    
    Args:
        api_key (str): API ключ для проверки
        
    Returns:
        dict: Информация о статусе ключа или None в случае ошибки
    """
    # Endpoint для получения URL для загрузки изображения
    url = "https://api.lightx.ai/api/v2/urls/upload"
    
    headers = {
        "Content-Type": "application/json",
        "x-api-key": api_key
    }
    
    # Размер тестового изображения (1 KB)
    test_size = 1024
    
    # Данные для запроса
    data = {
        "size": test_size,
        "contentType": "image/jpeg"
    }
    
    try:
        # Отправляем запрос
        response = requests.post(url, headers=headers, json=data)
        logger.info(f"Получен ответ API со статусом: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            logger.info(f"Успешно получен URL для загрузки: {result}")
            
            # Возвращаем информацию о ключе в формате, аналогичном credits API
            return {
                "status": "ACTIVE",
                "statusCode": 2000,
                "message": "API key is valid",
                "body": {
                    "total": "Unknown",
                    "used": "Unknown",
                    "available": "Active (verified via upload URL API)"
                }
            }
        elif response.status_code == 403:
            logger.error("Доступ запрещен - кредиты исчерпаны или ключ недействителен")
            return {"status": "FORBIDDEN", "statusCode": 403, "message": "Access forbidden"}
        else:
            logger.error(f"Ошибка при проверке API ключа через запрос URL: {response.status_code} - {response.text}")
            return None
    
    except Exception as e:
        logger.error(f"Исключение при проверке API ключа через запрос URL: {e}")
        return None
        
def parse_credits_info(credits_info):
    """
    Парсит информацию о кредитах и возвращает человекочитаемую строку
    
    Args:
        credits_info (dict): Информация о кредитах от API
        
    Returns:
        str: Строка с информацией о кредитах
    """
    if not credits_info:
        return "Информация о кредитах недоступна"
    
    if credits_info.get("status") == "FORBIDDEN":
        return "API ключ недействителен или кредиты исчерпаны"
    
    # Извлекаем информацию о кредитах
    try:
        total_credits = credits_info.get("body", {}).get("total", 0)
        used_credits = credits_info.get("body", {}).get("used", 0)
        available_credits = credits_info.get("body", {}).get("available", 0)
        
        # Форматируем результат
        result = f"Всего кредитов: {total_credits}\n"
        result += f"Использовано кредитов: {used_credits}\n"
        result += f"Доступно кредитов: {available_credits}\n"
        
        # Добавляем дату и время проверки
        result += f"Проверено: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        return result
    except Exception as e:
        logger.error(f"Ошибка при парсинге информации о кредитах: {e}")
        return "Ошибка при обработке информации о кредитах"

def check_all_api_keys(test_upload=False):
    """
    Проверяет все доступные API ключи LightX из переменных окружения
    и выводит их статус
    
    Args:
        test_upload (bool): Если True, проверяет ключи через API загрузки изображений
    """
    # Загружаем переменные окружения
    load_dotenv()
    
    test_method = "через API загрузки" if test_upload else "через Credits API"
    logger.info(f"Проверка API ключей {test_method}")
    
    # Проверяем основной API ключ
    main_key = os.environ.get("LIGHTX_API_KEY")
    if not main_key:
        logger.error("Основной API ключ (LIGHTX_API_KEY) не найден в переменных окружения")
    else:
        logger.info(f"Найден основной API ключ: {main_key[:8]}...{main_key[-8:]}")
        credits_info = check_api_key(main_key, test_upload=test_upload)
        print("\nОсновной API ключ LightX:")
        print(parse_credits_info(credits_info))
    
    # Проверяем наличие резервных API ключей
    for i in range(1, 4):
        backup_key = os.environ.get(f"LIGHTX_API_KEY_BACKUP_{i}")
        if backup_key:
            logger.info(f"Найден резервный API ключ #{i}: {backup_key[:8]}...{backup_key[-8:]}")
            credits_info = check_api_key(backup_key, test_upload=test_upload)
            print(f"\nРезервный API ключ LightX #{i}:")
            print(parse_credits_info(credits_info))
        else:
            logger.info(f"Резервный API ключ #{i} не найден")

def check_specific_api_key(api_key, test_upload=False):
    """
    Проверяет указанный API ключ и выводит его статус
    
    Args:
        api_key (str): API ключ для проверки
        test_upload (bool): Если True, проверяет ключ через API загрузки изображений
    """
    if not api_key:
        logger.error("API ключ не указан")
        return
    
    test_method = "через API загрузки" if test_upload else "через Credits API"
    logger.info(f"Проверка API ключа {test_method}")
        
    credits_info = check_api_key(api_key, test_upload=test_upload)
    print("\nСтатус указанного API ключа LightX:")
    print(parse_credits_info(credits_info))

def main():
    """
    Основная функция скрипта
    """
    parser = argparse.ArgumentParser(
        description="Проверка статуса API ключей LightX и отображение доступных кредитов",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    parser.add_argument(
        "--key", type=str, help="Проверка конкретного API ключа", default=None
    )
    
    parser.add_argument(
        "--all", action="store_true", 
        help="Проверить все доступные API ключи из переменных окружения"
    )
    
    parser.add_argument(
        "--method", choices=["credits", "upload"], default="credits",
        help="Метод проверки API ключей: credits - через API с информацией о кредитах, upload - через API загрузки изображений"
    )
    
    args = parser.parse_args()
    
    # Определяем, нужно ли использовать API загрузки
    test_upload = args.method == "upload"
    
    if args.key:
        check_specific_api_key(args.key, test_upload=test_upload)
    elif args.all:
        check_all_api_keys(test_upload=test_upload)
    else:
        # По умолчанию проверяем все ключи
        check_all_api_keys(test_upload=test_upload)

if __name__ == "__main__":
    main()