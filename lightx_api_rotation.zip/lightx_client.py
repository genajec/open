import os
import requests
import json
import logging
import time
import base64
from io import BytesIO
from config import LIGHTX_HAIRSTYLE_STYLES  # Импортируем стили причесок из конфига
import traceback  # Для детального логирования ошибок

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class LightXClient:
    """Client for LightX API for hairstyle generation"""
    
    def __init__(self):
        """Initialize the LightX client with API key from environment variables"""
        # Получаем основной API ключ
        self.api_key = os.environ.get("LIGHTX_API_KEY")
        
        # Получаем резервные API ключи
        self.backup_api_keys = []
        for i in range(1, 4):  # Ищем BACKUP_1, BACKUP_2, BACKUP_3
            backup_key = os.environ.get(f"LIGHTX_API_KEY_BACKUP_{i}")
            if backup_key:
                self.backup_api_keys.append(backup_key)
                logger.info(f"Найден резервный API ключ LightX #{i}")
        
        # Логируем информацию о количестве ключей
        logger.info(f"Всего доступно {len(self.backup_api_keys) + (1 if self.api_key else 0)} API ключей LightX")
        
        # Проверяем, есть ли хотя бы один ключ
        if not self.api_key and not self.backup_api_keys:
            logger.error("LightX API key not found in environment variables")
            raise ValueError("Missing LightX API key")
        
        # Если основной ключ отсутствует, но есть резервные, используем первый резервный
        if not self.api_key and self.backup_api_keys:
            self.api_key = self.backup_api_keys.pop(0)
            logger.info("Основной API ключ не найден, используем первый резервный ключ")
        
        # Добавляем счетчик ошибок для отслеживания проблем с API ключом
        self.api_error_count = 0
        self.max_api_errors = 3  # Максимальное количество ошибок до переключения ключа
        
        # Словарь резервных переводов для часто используемых слов (особенно для цветов)
        self.backup_translations = {
            # Цвета волос
            'черный': 'black hair',
            'черн': 'black hair',
            'черные волосы': 'black hair',
            'черного цвета': 'black color',
            'темный': 'dark',
            'каштановый': 'chestnut brown',
            'коричневый': 'brown',
            'русый': 'blonde',
            'блонд': 'blonde',
            'светлый': 'light blonde',
            'рыжий': 'red',
            'красный': 'red',
            'седой': 'gray',
            # Базовые фразы для причесок
            'волосы': 'hair',
            'прическа': 'hairstyle',
            'стрижка': 'haircut',
            'длинные': 'long',
            'короткие': 'short',
            'средней длины': 'medium length',
            'кудрявые': 'curly',
            'прямые': 'straight',
            'волнистые': 'wavy',
            # Базовые слова для фонов
            'фон': 'background',
            'задний план': 'background',
            'пляж': 'beach',
            'офис': 'office',
            'природа': 'nature',
            'город': 'city',
            'студия': 'studio'
        }
        
        # API endpoints
        self.upload_image_url = "https://api.lightxeditor.com/external/api/v2/uploadImageUrl"
        self.hairstyle_api_url = "https://api.lightxeditor.com/external/api/v1/hairstyle"
        self.order_status_url = "https://api.lightxeditor.com/external/api/v1/order-status"
        self.beautify_url = "https://api.lightxeditor.com/external/api/v2/beautify"  # Обновлено на v2
        self.inpainting_url = "https://api.lightxeditor.com/external/api/v1/inpainting"
        self.remove_bg_url = "https://api.lightxeditor.com/external/api/v1/remove-background"
        self.sketch2image_url = "https://api.lightxeditor.com/external/api/v1/sketch2image"
        self.text2image_url = "https://api.lightxeditor.com/external/api/v1/text2image"
        self.emotion_url = "https://api.lightxeditor.com/external/api/v1/emotion"
        self.replace_url = "https://api.lightxeditor.com/external/api/v1/replace"  # URL для Replace API
        
        # Headers for API requests
        self.headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key
        }
        
        # DeepL API key для перевода
        self.deepl_api_key = os.environ.get("DEEPL_API_KEY", "7fe9dd7a-990a-4bf1-86af-a216b1b993a1:fx")
        self.deepl_api_url = "https://api-free.deepl.com/v2/translate"
        
    def switch_to_next_api_key(self):
        """
        Переключается на следующий доступный API ключ в случае исчерпания кредитов текущего ключа
        
        Returns:
            bool: True если успешно переключились на новый ключ, False если больше нет доступных ключей
        """
        if not self.backup_api_keys:
            logger.warning("Нет доступных резервных API ключей для переключения")
            return False
            
        # Получаем следующий ключ из списка резервных
        new_key = self.backup_api_keys.pop(0)
        old_key = self.api_key
        
        # Сохраняем старый ключ в конец списка резервных (можно использовать позже)
        if old_key:
            self.backup_api_keys.append(old_key)
            
        # Обновляем текущий ключ
        self.api_key = new_key
        self.headers["x-api-key"] = new_key
        
        # Сбрасываем счетчик ошибок
        self.api_error_count = 0
        
        logger.info(f"Переключение на новый API ключ LightX. Осталось резервных ключей: {len(self.backup_api_keys)}")
        return True
        
    def check_credits_exhausted(self, response):
        """
        Проверяет, исчерпаны ли кредиты текущего API ключа на основе ответа API
        
        Args:
            response: Ответ API запроса
            
        Returns:
            bool: True если кредиты исчерпаны, False в противном случае
        """
        # Проверяем наличие ответа
        if not response:
            return False
            
        # Проверяем статус код
        if response.status_code == 402:  # Payment Required
            logger.warning(f"Обнаружено исчерпание кредитов API ключа LightX: {response.text}")
            return True
            
        try:
            # Анализируем текст ответа для поиска ошибок, связанных с кредитами
            result = response.json()
            
            # Проверяем код ответа
            if result.get("statusCode") in [4001, 4002, 4003]:  # Коды ошибок, связанные с кредитами
                logger.warning(f"Обнаружен код ошибки, связанный с исчерпанием кредитов: {result.get('statusCode')}")
                return True
                
            # Проверяем сообщение об ошибке
            error_msg = str(result.get("message", "")).lower()
            credit_keywords = ["credit", "quota", "payment", "limit", "exceeded", "balance"]
            
            for keyword in credit_keywords:
                if keyword in error_msg:
                    logger.warning(f"Обнаружено ключевое слово '{keyword}' в сообщении об ошибке: {error_msg}")
                    return True
                    
        except Exception as e:
            logger.error(f"Ошибка при анализе ответа API на исчерпание кредитов: {e}")
            
        return False
        
    def handle_api_response(self, response, context="API request"):
        """
        Обрабатывает ответ API и автоматически переключает ключ при необходимости
        
        Args:
            response: Ответ API запроса
            context (str): Контекст запроса для логирования
            
        Returns:
            bool: True если ответ успешный или произошло успешное переключение ключа, False в случае ошибки
        """
        # Проверяем наличие ответа
        if not response:
            logger.error(f"Пустой ответ от API в контексте: {context}")
            self.api_error_count += 1
            return False
            
        # Проверяем успешность запроса
        if response.status_code == 200:
            # Успешный запрос, сбрасываем счетчик ошибок
            self.api_error_count = 0
            return True
            
        # Проверяем исчерпание кредитов
        if self.check_credits_exhausted(response):
            logger.warning(f"Обнаружено исчерпание кредитов API ключа LightX в контексте: {context}")
            
            # Пытаемся переключиться на следующий ключ
            if self.switch_to_next_api_key():
                logger.info(f"Успешно переключились на новый API ключ LightX")
                return True
            else:
                logger.error(f"Не удалось переключиться на новый API ключ - все ключи исчерпаны")
                return False
                
        # Увеличиваем счетчик ошибок
        self.api_error_count += 1
        
        # Если количество последовательных ошибок превысило порог, пробуем переключить ключ
        if self.api_error_count >= self.max_api_errors:
            logger.warning(f"Достигнуто максимальное количество ошибок API ({self.api_error_count}). Пробуем другой ключ...")
            
            if self.switch_to_next_api_key():
                logger.info(f"Успешно переключились на новый API ключ LightX после серии ошибок")
                return True
                
        return False
        
    def translate_with_deepl(self, text, source_lang="RU", target_lang="EN"):
        """
        Переводит текст с помощью DeepL API
        
        Args:
            text (str): Исходный текст для перевода
            source_lang (str): Язык исходного текста (по умолчанию "RU" - русский)
            target_lang (str): Язык, на который нужно перевести (по умолчанию "EN" - английский)
            
        Returns:
            str: Переведенный текст или резервный перевод на основе словаря при ошибке
        """
        # Проверяем, не является ли текст пустым или None
        if not text:
            logger.warning("Attempted to translate empty text")
            return text
            
        # Если текст уже на английском языке, просто возвращаем его
        if text.strip().isascii():
            logger.info(f"Text already appears to be in English, skipping translation: '{text}'")
            return text
            
        # Сначала проверяем, есть ли точное совпадение в нашем словаре резервных переводов
        text_lower = text.lower().strip()
        if text_lower in self.backup_translations:
            translated = self.backup_translations[text_lower]
            logger.info(f"Found exact match in backup dictionary: '{text}' -> '{translated}'")
            return translated
        
        # Проверяем наличие ключевых слов о цвете волос
        for key_word in ['черный', 'черные', 'черн']:
            if key_word in text_lower and ('волосы' in text_lower or 'цвет' in text_lower):
                logger.info(f"Found 'black' keyword in text: '{text}'")
                result = text_lower.replace(key_word, 'black')
                result = result.replace('волосы', 'hair')
                result = result.replace('цвет', 'color')
                logger.info(f"Basic translation: '{text}' -> '{result}'")
                return result
        
        try:
            # Заголовки с ключом API
            headers = {
                "Authorization": f"DeepL-Auth-Key {self.deepl_api_key}",
                "Content-Type": "application/json"
            }
            
            # Данные для запроса
            data = {
                "text": [text],
                "source_lang": source_lang,
                "target_lang": target_lang
            }
            
            logger.info(f"Sending translation request to DeepL API for text: '{text}'")
            
            # Отправляем запрос
            response = requests.post(self.deepl_api_url, json=data, headers=headers)
            
            # Проверяем успешность запроса
            if response.status_code == 200:
                result = response.json()
                logger.info(f"DeepL API response: {result}")
                
                if "translations" in result and len(result["translations"]) > 0:
                    translated_text = result["translations"][0]["text"]
                    logger.info(f"DeepL translation successful: '{text}' -> '{translated_text}'")
                    
                    # Проверяем результат перевода на наличие ключевых слов для чёрного цвета
                    if ('черный' in text_lower or 'черные' in text_lower or 'черного' in text_lower) and 'black' not in translated_text.lower():
                        logger.warning(f"DeepL did not translate 'черный' to 'black'. Original: '{text}', Translation: '{translated_text}'")
                        # Принудительно добавляем 'black' в перевод
                        if 'hair' in translated_text.lower():
                            translated_text = translated_text.lower().replace('hair', 'black hair')
                        else:
                            translated_text = f"black {translated_text}"
                        logger.info(f"Corrected translation for black color: '{translated_text}'")
                    
                    return translated_text
                else:
                    logger.warning(f"DeepL API returned 200 but no translations found in response: {result}")
            else:
                # Если запрос неуспешен, логируем ошибку и используем резервный перевод
                logger.warning(f"DeepL API error: {response.status_code} - {response.text}")
        except Exception as e:
            logger.error(f"Error in DeepL API: {e}")
            logger.error(f"Stack trace: {traceback.format_exc()}")
        
        # Если дошли до этого места, значит перевод через API не удался,
        # пробуем использовать базовые замены для русских слов
        logger.info(f"Using backup dictionary translation for: '{text}'")
        
        result = text_lower
        for rus_word, eng_word in self.backup_translations.items():
            if rus_word in result:
                result = result.replace(rus_word, eng_word)
        
        if result != text_lower:
            logger.info(f"Backup translation: '{text}' -> '{result}'")
            return result
            
        # Если ничего не сработало, возвращаем исходный текст
        logger.warning(f"No translation available for: '{text}', returning original")
        return text
        
    def get_image_upload_url(self, image_size, content_type="image/jpeg", max_attempts=3):
        """
        Get a URL for uploading an image to LightX service with automatic key switching if needed
        
        Args:
            image_size (int): Size of the image in bytes
            content_type (str): Content type of the image
            max_attempts (int): Максимальное количество попыток с разными ключами
            
        Returns:
            tuple: (upload_url, image_url) or (None, None) if there's an error
        """
        attempt = 0
        
        while attempt < max_attempts:
            try:
                # Prepare request data
                data = {
                    "uploadType": "imageUrl",
                    "size": image_size,
                    "contentType": content_type
                }
                
                # Make the request
                logger.info(f"Requesting image upload URL from LightX API (попытка {attempt+1}/{max_attempts})")
                response = requests.post(self.upload_image_url, headers=self.headers, json=data)
                
                # Проверяем ответ API на исчерпание кредитов
                if self.check_credits_exhausted(response):
                    logger.warning("Обнаружено исчерпание кредитов API ключа при запросе URL загрузки")
                    
                    # Пробуем переключиться на следующий ключ
                    if not self.switch_to_next_api_key():
                        logger.error("Не удалось переключиться на новый API ключ - все ключи исчерпаны")
                        return None, None
                        
                    # Увеличиваем счетчик попыток и продолжаем цикл
                    attempt += 1
                    continue
                
                # Check response
                if response.status_code != 200:
                    logger.error(f"Failed to get upload URL: {response.status_code} - {response.text}")
                    
                    # Увеличиваем счетчик ошибок API
                    self.api_error_count += 1
                    
                    # Если достигнут максимум ошибок, пробуем сменить ключ
                    if self.api_error_count >= self.max_api_errors:
                        if self.switch_to_next_api_key():
                            logger.info("Переключились на новый API ключ после серии ошибок")
                            attempt += 1
                            continue
                    
                    return None, None
                    
                # Parse response
                result = response.json()
                if result.get("statusCode") != 2000 or "body" not in result:
                    logger.error(f"Invalid response from upload URL API: {result}")
                    return None, None
                    
                # Extract URLs
                upload_image = result["body"].get("uploadImage")
                image_url = result["body"].get("imageUrl")
                
                if not upload_image or not image_url:
                    logger.error("Missing upload URLs in response")
                    return None, None
                    
                # Успешный запрос, сбрасываем счетчик ошибок
                self.api_error_count = 0
                
                logger.info(f"Successfully obtained upload URL: {image_url}")
                return upload_image, image_url
                
            except Exception as e:
                logger.error(f"Error getting image upload URL: {e}")
                
                # Увеличиваем счетчик попыток
                attempt += 1
                
                # Если есть еще попытки, пробуем переключиться на другой ключ
                if attempt < max_attempts and self.switch_to_next_api_key():
                    logger.info(f"Переключились на новый API ключ после ошибки. Попытка {attempt+1}/{max_attempts}")
                    continue
                
                return None, None
                
        # Если все попытки исчерпаны
        logger.error(f"Исчерпаны все попытки ({max_attempts}) получить URL для загрузки изображения")
        return None, None
            
    def upload_image(self, image_data, max_attempts=3):
        """
        Upload an image to LightX service with automatic key switching if needed
        
        Args:
            image_data (bytes): Image data
            max_attempts (int): Максимальное количество попыток с разными ключами
            
        Returns:
            str: URL of the uploaded image or None if there's an error
        """
        attempt = 0
        
        while attempt < max_attempts:
            try:
                # Get image size
                image_size = len(image_data)
                
                # Get upload URL
                logger.info(f"Получение URL для загрузки изображения (попытка {attempt+1}/{max_attempts})")
                upload_url, image_url = self.get_image_upload_url(image_size, max_attempts=1)
                if not upload_url or not image_url:
                    # Если не удалось получить URL, пробуем другой ключ API
                    if self.switch_to_next_api_key():
                        logger.info(f"Переключились на новый API ключ после ошибки получения URL. Попытка {attempt+2}/{max_attempts}")
                        attempt += 1
                        continue
                    return None
                    
                # Prepare headers for PUT request
                put_headers = {
                    "Content-Type": "image/jpeg"
                }
                
                # Upload the image
                logger.info(f"Uploading image to {upload_url} (попытка {attempt+1}/{max_attempts})")
                put_response = requests.put(upload_url, headers=put_headers, data=image_data)
                
                # Check response
                if put_response.status_code != 200:
                    logger.error(f"Failed to upload image: {put_response.status_code} - {put_response.text}")
                    
                    # Пробуем переключиться на следующий ключ
                    if self.switch_to_next_api_key():
                        logger.info(f"Переключились на новый API ключ после ошибки загрузки. Попытка {attempt+2}/{max_attempts}")
                        attempt += 1
                        continue
                    
                    return None
                    
                logger.info(f"Successfully uploaded image. Image URL: {image_url}")
                
                # Успешное выполнение, сбрасываем счетчик ошибок
                self.api_error_count = 0
                
                return image_url
                
            except Exception as e:
                logger.error(f"Error uploading image: {e}")
                
                # Увеличиваем счетчик попыток
                attempt += 1
                
                # Пробуем переключиться на следующий ключ
                if attempt < max_attempts and self.switch_to_next_api_key():
                    logger.info(f"Переключились на новый API ключ после общей ошибки. Попытка {attempt+1}/{max_attempts}")
                    continue
                
                return None
                
        # Если все попытки исчерпаны
        logger.error(f"Исчерпаны все попытки ({max_attempts}) загрузить изображение")
        return None
            
    def generate_hairstyle(self, image_url, text_prompt, max_attempts=3):
        """
        Generate a hairstyle using LightX API with automatic key switching if needed
        
        Args:
            image_url (str): URL of the uploaded image
            text_prompt (str): Text prompt describing the hairstyle
            max_attempts (int): Максимальное количество попыток с разными ключами
            
        Returns:
            str: Order ID for checking status or None if there's an error
        """
        attempt = 0
        
        while attempt < max_attempts:
            try:
                # Переводим запрос с русского на английский
                translated_prompt = self.translate_with_deepl(text_prompt)
                logger.info(f"Translated hairstyle prompt: '{text_prompt}' -> '{translated_prompt}'")
                
                # Добавляем глобальные инструкции для сохранения лица и фона
                preserve_instructions = "preserve facial features exactly, do not change face shape or characteristics, maintain same facial expression, keep original background unchanged, same face same person, only change hairstyle"
                
                # Комбинируем основной запрос с инструкциями сохранения
                enhanced_prompt = f"{translated_prompt}, {preserve_instructions}"
                
                # Prepare request data
                data = {
                    "imageUrl": image_url,
                    "textPrompt": enhanced_prompt
                }
                
                # Make the request
                logger.info(f"Requesting hairstyle generation with prompt (попытка {attempt+1}/{max_attempts}): {enhanced_prompt}")
                response = requests.post(self.hairstyle_api_url, headers=self.headers, json=data)
                
                # Проверяем ответ API на исчерпание кредитов
                if self.check_credits_exhausted(response):
                    logger.warning("Обнаружено исчерпание кредитов API ключа при генерации прически")
                    
                    # Пробуем переключиться на следующий ключ
                    if not self.switch_to_next_api_key():
                        logger.error("Не удалось переключиться на новый API ключ - все ключи исчерпаны")
                        return None
                        
                    # Увеличиваем счетчик попыток и продолжаем цикл
                    attempt += 1
                    continue
                
                # Check response
                if response.status_code != 200:
                    logger.error(f"Failed to request hairstyle generation: {response.status_code} - {response.text}")
                    
                    # Увеличиваем счетчик ошибок API
                    self.api_error_count += 1
                    
                    # Если достигнут максимум ошибок, пробуем сменить ключ
                    if self.api_error_count >= self.max_api_errors:
                        if self.switch_to_next_api_key():
                            logger.info("Переключились на новый API ключ после серии ошибок")
                            attempt += 1
                            continue
                            
                    return None
                    
                # Parse response
                result = response.json()
                if result.get("statusCode") != 2000 or "body" not in result:
                    logger.error(f"Invalid response from hairstyle API: {result}")
                    
                    # Проверяем сообщение об ошибке на признаки исчерпания кредитов
                    error_msg = str(result.get("message", "")).lower()
                    if any(keyword in error_msg for keyword in ["credit", "quota", "limit", "balance"]):
                        logger.warning(f"Обнаружены признаки исчерпания кредитов в ответе API: {error_msg}")
                        
                        if self.switch_to_next_api_key():
                            logger.info("Переключились на новый API ключ после обнаружения ошибки кредитов")
                            attempt += 1
                            continue
                            
                    return None
                    
                # Extract order ID
                order_id = result["body"].get("orderId")
                if not order_id:
                    logger.error("Missing order ID in response")
                    return None
                    
                # Успешный запрос, сбрасываем счетчик ошибок
                self.api_error_count = 0
                
                logger.info(f"Successfully requested hairstyle generation. Order ID: {order_id}")
                return order_id
                
            except Exception as e:
                logger.error(f"Error requesting hairstyle generation: {e}")
                
                # Увеличиваем счетчик попыток
                attempt += 1
                
                # Если есть еще попытки, пробуем переключиться на другой ключ
                if attempt < max_attempts and self.switch_to_next_api_key():
                    logger.info(f"Переключились на новый API ключ после ошибки. Попытка {attempt+1}/{max_attempts}")
                    continue
                
                return None
                
        # Если все попытки исчерпаны
        logger.error(f"Исчерпаны все попытки ({max_attempts}) сгенерировать прическу")
        return None
            
    def check_order_status(self, order_id, max_attempts=3):
        """
        Check the status of an order (hairstyle, background, etc.) with automatic key switching if needed
        
        Args:
            order_id (str): Order ID
            max_attempts (int): Максимальное количество попыток с разными ключами
            
        Returns:
            tuple: (status, output_url) or (None, None) if there's an error
        """
        attempt = 0
        
        while attempt < max_attempts:
            try:
                # Prepare request data - используем строго формат из документации API
                data = {
                    "orderId": order_id  # Точно так же, как в документации
                }
                
                # Заголовки для запроса статуса
                headers = {
                    "Content-Type": "application/json",
                    "x-api-key": self.api_key
                }
                
                # Make the request
                logger.info(f"Проверка статуса заказа {order_id} в LightX API (попытка {attempt+1}/{max_attempts})")
                logger.info(f"URL запроса: {self.order_status_url}")
                logger.info(f"Заголовки запроса: {headers}")
                logger.info(f"Тело запроса: {data}")
                
                # Отправляем запрос строго как указано в документации
                response = requests.post(self.order_status_url, headers=headers, json=data)
                
                logger.info(f"Получен ответ API со статусом: {response.status_code}")
                logger.info(f"Текст ответа: {response.text[:200]}...")  # Логируем только начало текста ответа
                
                # Проверяем ответ API на исчерпание кредитов
                if self.check_credits_exhausted(response):
                    logger.warning("Обнаружено исчерпание кредитов API ключа при проверке статуса заказа")
                    
                    # Пробуем переключиться на следующий ключ
                    if not self.switch_to_next_api_key():
                        logger.error("Не удалось переключиться на новый API ключ - все ключи исчерпаны")
                        return None, None
                        
                    # Увеличиваем счетчик попыток и продолжаем цикл
                    attempt += 1
                    continue
                
                # Check response
                if response.status_code != 200:
                    logger.error(f"Failed to check order status: {response.status_code} - {response.text}")
                    
                    # Увеличиваем счетчик ошибок API
                    self.api_error_count += 1
                    
                    # Если достигнут максимум ошибок, пробуем сменить ключ
                    if self.api_error_count >= self.max_api_errors:
                        if self.switch_to_next_api_key():
                            logger.info("Переключились на новый API ключ после серии ошибок")
                            attempt += 1
                            continue
                            
                    return None, None
                    
                # Parse response
                result = response.json()
                if result.get("statusCode") != 2000 or "body" not in result:
                    logger.error(f"Invalid response from order status API: {result}")
                    
                    # Проверяем сообщение об ошибке на признаки исчерпания кредитов
                    error_msg = str(result.get("message", "")).lower()
                    if any(keyword in error_msg for keyword in ["credit", "quota", "limit", "balance"]):
                        logger.warning(f"Обнаружены признаки исчерпания кредитов в ответе API: {error_msg}")
                        
                        if self.switch_to_next_api_key():
                            logger.info("Переключились на новый API ключ после обнаружения ошибки кредитов")
                            attempt += 1
                            continue
                            
                    return None, None
                    
                # Extract status and output URL
                status = result["body"].get("status")
                output_url = result["body"].get("output")
                
                # Успешный запрос, сбрасываем счетчик ошибок
                self.api_error_count = 0
                
                logger.info(f"Статус заказа: {status}, URL результата: {output_url if output_url else 'еще не готов'}")
                return status, output_url
                
            except Exception as e:
                logger.error(f"Error checking order status: {e}")
                
                # Увеличиваем счетчик попыток
                attempt += 1
                
                # Пробуем переключиться на следующий ключ
                if attempt < max_attempts and self.switch_to_next_api_key():
                    logger.info(f"Переключились на новый API ключ после ошибки проверки статуса. Попытка {attempt+1}/{max_attempts}")
                    continue
                
                return None, None
                
        # Если все попытки исчерпаны
        logger.error(f"Исчерпаны все попытки ({max_attempts}) проверить статус заказа")
        return None, None
            
    def wait_for_result(self, order_id, max_retries=5, retry_interval=3, max_api_attempts=3):
        """
        Wait for the result of a hairstyle generation order with automatic key switching if needed
        
        Args:
            order_id (str): Order ID
            max_retries (int): Maximum number of retry attempts for status checking
            retry_interval (int): Time between retries in seconds
            max_api_attempts (int): Maximum number of attempts with different API keys
            
        Returns:
            str: URL of the generated image or None if there's an error
        """
        try:
            for attempt in range(max_retries):
                logger.info(f"Waiting for result, attempt {attempt+1}/{max_retries}")
                
                # Wait before checking
                time.sleep(retry_interval)
                
                # Check status with automatic key switching if needed
                status, output_url = self.check_order_status(order_id, max_attempts=max_api_attempts)
                
                # Если не удалось получить статус после всех попыток с разными ключами API
                if status is None:
                    logger.error(f"Failed to get order status after {max_api_attempts} attempts with different API keys")
                    
                    # Если это не последняя попытка ожидания, продолжаем
                    if attempt < max_retries - 1:
                        logger.info(f"Will try again in {retry_interval} seconds")
                        continue
                    else:
                        logger.error("Maximum retries reached, giving up")
                        return None
                
                # If active and output is available, return it
                if status == "active" and output_url:
                    logger.info(f"Order completed successfully. Output URL: {output_url}")
                    return output_url
                    
                # If still in progress, continue waiting
                elif status == "init":
                    logger.info("Order is still being processed")
                    continue
                    
                # If failed, stop waiting
                elif status == "failed":
                    logger.error("Order processing failed")
                    return None
                    
                # Unknown status
                else:
                    logger.warning(f"Unknown order status: {status}")
                    
            logger.error(f"Maximum retries ({max_retries}) reached while waiting for result")
            return None
            
        except Exception as e:
            logger.error(f"Error waiting for result: {e}")
            logger.error(f"Stack trace: {traceback.format_exc()}")
            return None
            
    def apply_hairstyle(self, image_data, hairstyle_prompt, max_attempts=3):
        """
        Apply a hairstyle to an image using LightX API with automatic key switching if needed
        
        Args:
            image_data (bytes): Image data
            hairstyle_prompt (str): Text prompt describing the hairstyle
            max_attempts (int): Максимальное количество попыток с разными ключами
            
        Returns:
            bytes: Generated image with the hairstyle applied or None if there's an error
        """
        attempt = 0
        
        while attempt < max_attempts:
            try:
                logger.info(f"Starting hairstyle generation process with LightX API (попытка {attempt+1}/{max_attempts})")
                logger.info(f"Original hairstyle prompt: {hairstyle_prompt}")
                logger.info(f"Image data size: {len(image_data)} bytes")
                
                # Переводим запрос с русского на английский
                translated_prompt = self.translate_with_deepl(hairstyle_prompt)
                logger.info(f"Translated hairstyle prompt: '{hairstyle_prompt}' -> '{translated_prompt}'")
                
                # Проверяем, содержит ли запрос упоминание черного цвета
                prompt_lower = translated_prompt.lower()
                original_lower = hairstyle_prompt.lower()
                
                # Проверка на ключевые слова черного цвета на английском и русском
                is_black_color = any(word in original_lower for word in ['черные волосы', 'черный', 'черные']) or 'black' in prompt_lower
                
                # Если черный цвет присутствовал в запросе, но нет слова "black", добавим его явно
                if is_black_color and 'black' not in prompt_lower:
                    logger.info(f"Обнаружены ключевые слова для черного цвета волос, но слово 'black' отсутствует в запросе")
                    if 'hair' in prompt_lower:
                        # Заменяем "hair" на "black hair" 
                        translated_prompt = translated_prompt.replace('hair', 'black hair')
                        logger.info(f"Заменили 'hair' на 'black hair': {translated_prompt}")
                    else:
                        # Если hair отсутствует, добавляем "black hair" в запрос
                        translated_prompt = f"black hair, {translated_prompt}"
                        logger.info(f"Добавили 'black hair' в запрос: {translated_prompt}")
                
                # Добавляем инструкции для сохранения черт лица и фона
                preserve_instructions = "preserve exact facial features, do not change face, maintain facial expression, keep original background unchanged, same face same person, only modify hairstyle"
                
                # Комбинируем основной запрос с инструкциями сохранения
                enhanced_prompt = f"{translated_prompt}, {preserve_instructions}"
                
                # Для запросов с черным цветом, добавляем явные инструкции
                if is_black_color:
                    enhanced_prompt = f"{enhanced_prompt}, deep black hair color, solid black, no highlights"
                    logger.info(f"Добавлены специальные инструкции для черного цвета волос: {enhanced_prompt}")
                
                # Upload the image
                logger.info(f"Step 1: Uploading image to LightX API (попытка {attempt+1}/{max_attempts})...")
                image_url = self.upload_image(image_data)
                if not image_url:
                    logger.error("Failed to upload image")
                    
                    # Пробуем переключиться на следующий ключ и повторить попытку
                    if self.switch_to_next_api_key():
                        logger.info(f"Переключились на новый API ключ после ошибки загрузки изображения. Попытка {attempt+2}/{max_attempts}")
                        attempt += 1
                        continue
                    
                    return None
                    
                # Generate hairstyle
                logger.info(f"Step 2: Generating hairstyle with prompt (попытка {attempt+1}/{max_attempts}): {enhanced_prompt}")
                order_id = self.generate_hairstyle(image_url, enhanced_prompt)
                if not order_id:
                    logger.error("Failed to generate hairstyle - no order ID received")
                    
                    # Пробуем переключиться на следующий ключ и повторить попытку
                    if self.switch_to_next_api_key():
                        logger.info(f"Переключились на новый API ключ после ошибки генерации прически. Попытка {attempt+2}/{max_attempts}")
                        attempt += 1
                        continue
                    
                    return None
                    
                # Wait for the result
                logger.info(f"Step 3: Waiting for processing to complete (попытка {attempt+1}/{max_attempts}). Order ID: {order_id}")
                output_url = self.wait_for_result(order_id, max_retries=10, retry_interval=2)
                if not output_url:
                    logger.error("Failed to get result URL after waiting")
                    
                    # Пробуем переключиться на следующий ключ и повторить попытку
                    if self.switch_to_next_api_key():
                        logger.info(f"Переключились на новый API ключ после ошибки получения результата. Попытка {attempt+2}/{max_attempts}")
                        attempt += 1
                        continue
                    
                    return None
                    
                # Download the result
                logger.info(f"Step 4: Downloading result (попытка {attempt+1}/{max_attempts}) from {output_url}")
                response = requests.get(output_url)
                
                # Check response
                if response.status_code != 200:
                    logger.error(f"Failed to download result: {response.status_code}")
                    
                    # Пробуем переключиться на следующий ключ и повторить попытку
                    if self.switch_to_next_api_key():
                        logger.info(f"Переключились на новый API ключ после ошибки загрузки результата. Попытка {attempt+2}/{max_attempts}")
                        attempt += 1
                        continue
                    
                    return None
                    
                logger.info(f"Successfully completed hairstyle generation! Result size: {len(response.content)} bytes")
                
                # Успешное выполнение, сбрасываем счетчик ошибок
                self.api_error_count = 0
                
                return response.content
                
            except Exception as e:
                logger.error(f"Error applying hairstyle: {e}")
                # Log более подробную информацию об ошибке
                import traceback
                logger.error(f"Stack trace: {traceback.format_exc()}")
                
                # Увеличиваем счетчик попыток
                attempt += 1
                
                # Пробуем переключиться на следующий ключ
                if attempt < max_attempts and self.switch_to_next_api_key():
                    logger.info(f"Переключились на новый API ключ после общей ошибки. Попытка {attempt+1}/{max_attempts}")
                    continue
                
                return None
                
        # Если все попытки исчерпаны
        logger.error(f"Исчерпаны все попытки ({max_attempts}) для генерации прически")
        return None
            
    def get_hairstyle_prompts_by_face_shape(self, face_shape_param, gender_param=None):
        """
        Get hairstyle prompts recommended for a specific face shape and gender
        
        Args:
            face_shape_param (str): Face shape (OVAL, ROUND, SQUARE, HEART, OBLONG, DIAMOND)
            gender_param (str, optional): Gender for filtering hairstyles (male, female)
            
        Returns:
            list: List of hairstyle prompts
        """
        # Для обратной совместимости с кодом, который ожидает имена face_shape и gender
        face_shape = face_shape_param
        gender = gender_param
        # Преобразуем данные из конфига в формат, который ожидает метод
        hairstyle_prompts = []
        
        # Получаем стили для указанной формы лица
        face_shape_styles = LIGHTX_HAIRSTYLE_STYLES.get(face_shape, LIGHTX_HAIRSTYLE_STYLES.get("OVAL", []))
        
        # Логгируем полученные стили для отладки
        logger.info(f"Getting hairstyle prompts for {face_shape} from config: {len(face_shape_styles)} styles available")
        
        # Фильтрация по полу, если указан
        if gender:
            gender_marker = "(M)" if gender == "male" else "(Ж)"
            opposite_marker = "(Ж)" if gender == "male" else "(M)"
            
            # Находим прически с нужной меткой пола
            gender_specific_styles = []
            universal_styles = []
            
            for style in face_shape_styles:
                style_name = style.get("name", "")
                # Проверяем, соответствует ли стиль указанному полу
                if gender_marker in style_name:
                    gender_specific_styles.append(style)
                # Проверяем, это универсальная прическа (без пометок пола)
                elif opposite_marker not in style_name:
                    universal_styles.append(style)
            
            # Объединяем специфичные для пола и универсальные стили
            face_shape_styles = gender_specific_styles + universal_styles
            
            logger.info(f"Filtered styles by gender ({gender}): {len(gender_specific_styles)} gender-specific + {len(universal_styles)} universal styles = {len(face_shape_styles)} total")
        
        # Преобразуем формат
        for i, style in enumerate(face_shape_styles):
            # Сохраняем и "style" и "prompt" для обратной совместимости
            hairstyle_prompt = {
                "id": f"{face_shape.lower()}_{i+1}",
                "name": style.get("name", f"Стиль {i+1}"),
                "prompt": style.get("style", "elegant hairstyle"),
                "style": style.get("style", "elegant hairstyle")
            }
            
            logger.debug(f"Created hairstyle prompt: {hairstyle_prompt}")
            hairstyle_prompts.append(hairstyle_prompt)
        
        # Если список пуст (что неожиданно), используем значения по умолчанию
        if not hairstyle_prompts:
            logger.warning(f"No hairstyle prompts found for {face_shape} and gender {gender}, using defaults")
            if gender == "male":
                hairstyle_prompts = [
                    {
                        "id": "default_male_1", 
                        "name": "Классическая мужская стрижка", 
                        "prompt": "classic men's haircut, short sides, clean professional look",
                        "style": "classic men's haircut, short sides, clean professional look"
                    },
                    {
                        "id": "default_male_2", 
                        "name": "Современный мужской стиль", 
                        "prompt": "modern men's hairstyle, textured top",
                        "style": "modern men's hairstyle, textured top"
                    }
                ]
            else:
                hairstyle_prompts = [
                    {
                        "id": "default_female_1", 
                        "name": "Классический боб", 
                        "prompt": "classic bob haircut, shoulder length, straight hair",
                        "style": "classic bob haircut, shoulder length, straight hair"
                    },
                    {
                        "id": "default_female_2", 
                        "name": "Элегантный женский стиль", 
                        "prompt": "elegant women's hairstyle, professional looking",
                        "style": "elegant women's hairstyle, professional looking"
                    }
                ]
        
        logger.info(f"Returning {len(hairstyle_prompts)} hairstyle prompts for {face_shape} with gender {gender}")
        return hairstyle_prompts
        
    # Добавленные методы для дополнительных функций меню 4-9
    
    def retouch_photo(self, image_data):
        """
        Ретуширует фотографию, улучшая ее качество
        
        Args:
            image_data (bytes): Исходная фотография
            
        Returns:
            bytes: Ретушированная фотография или None, если ошибка
        """
        try:
            # Загружаем изображение
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for retouching")
                return None
                
            # Создаем запрос для ретуши фото (используем специальный API LightX)
            data = {
                "imageUrl": image_url,
                "options": {
                    "skinSmoothing": True,
                    "enhanceFeatures": True,
                    "removeImperfections": True,
                    "improveContrast": True,
                    "level": 0.75  # Уровень ретуши (0-1)
                }
            }
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting photo retouching with image URL: {image_url}")
            response = requests.post(self.beautify_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request photo retouching: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from beautify API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download retouched photo: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error retouching photo: {e}")
            return None
            
    
    def change_background(self, image_data, background_prompt, style_image_data=None):
        """
        Меняет фон на фотографии используя API удаления фона с последующей установкой нового фона
        
        Args:
            image_data (bytes): Исходная фотография
            background_prompt (str): Текстовое описание или цвет нового фона (например, "#FFFFFF" для белого)
            style_image_data (bytes, optional): Изображение стиля для применения к фону
            
        Returns:
            bytes: Фотография с новым фоном или None, если ошибка
        """
        # Проверка наличия API ключа LightX перед отправкой запроса
        if not self.api_key:
            logger.error("CRITICAL ERROR: LIGHTX_API_KEY не найден в переменных окружения!")
            logger.error("Убедитесь, что API ключ LightX добавлен в переменные окружения под именем LIGHTX_API_KEY")
            return None
            
        try:
            # Переводим текстовый запрос с русского на английский, если это не HEX-код цвета
            if background_prompt and not background_prompt.startswith('#') and len(background_prompt) > 2:
                original_prompt = background_prompt
                background_prompt = self.translate_with_deepl(background_prompt)
                logger.info(f"Translated background prompt: '{original_prompt}' -> '{background_prompt}'")
            
            # Подготовка цвета фона или URL изображения фона
            bg_value = background_prompt
            
            # Проверяем, является ли фон цветом в формате HEX
            import re
            is_hex_color = re.match(r'^#(?:[0-9a-fA-F]{3}){1,2}$', str(bg_value)) is not None
            
            # Если это не HEX-цвет и не URL изображения, используем белый цвет по умолчанию
            if not is_hex_color and not (isinstance(bg_value, str) and bg_value.startswith('http')):
                logger.info(f"Промпт '{bg_value}' не является цветом HEX или URL изображения, используем белый цвет #FFFFFF")
                bg_value = "#FFFFFF"
                
            # Шаг 1: Загружаем основное изображение
            logger.info(f"Шаг 1: Загрузка оригинального изображения на сервер LightX")
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for background change")
                return None
                
            logger.info(f"Успешно загружено основное изображение, получен URL: {image_url}")
            
            # Шаг 2: Отправляем запрос на удаление фона с заменой на новый
            logger.info(f"Шаг 2: Отправка запроса на удаление фона с заменой на: '{bg_value}'")
            
            # URL для API удаления фона
            remove_bg_url = "https://api.lightxeditor.com/external/api/v1/remove-background"
            
            # Данные для запроса согласно документации API
            data = {
                "imageUrl": image_url,
                "background": bg_value  # Цвет фона или URL изображения фона
            }
            
            # Заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            logger.info(f"URL запроса: {remove_bg_url}")
            logger.info(f"Заголовки запроса: {headers}")
            logger.info(f"Тело запроса: {data}")
            
            # Отправляем запрос
            response = requests.post(remove_bg_url, headers=headers, json=data)
            logger.info(f"Получен ответ API со статусом: {response.status_code}")
            logger.info(f"Текст ответа: {response.text[:200]}...")  # Логируем только начало текста ответа
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request background removal: {response.status_code} - {response.text}")
                return None
                
            logger.info(f"Запрос успешно отправлен, получен ответ статус {response.status_code}")
            
            # Анализируем ответ
            result = response.json()
            
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from remove-background API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            logger.info(f"Получен ID заказа: {order_id}")
            
            # Шаг 3: Ожидаем результат
            logger.info(f"Шаг 3: Ожидание обработки изображения...")
            
            # Увеличиваем количество попыток и интервал ожидания
            output_url = self.wait_for_result(order_id, max_retries=20, retry_interval=3)
            if not output_url:
                logger.error("Failed to get output URL after waiting")
                return None
                
            logger.info(f"Обработка завершена, получен URL результата: {output_url}")
            
            # Шаг 4: Загружаем результат
            logger.info(f"Шаг 4: Загрузка обработанного изображения")
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download image with new background: {response.status_code}")
                return None
                
            logger.info(f"Успешно загружено обработанное изображение, размер: {len(response.content)} байт")
            return response.content
            
        except Exception as e:
            logger.error(f"Error changing background: {e}")
            # Более подробное логирование ошибки
            import traceback
            logger.error(f"Stack trace: {traceback.format_exc()}")
            return None
    

    def generate_portrait(self, image_data, style_prompt):
        """
        Генерирует портрет в заданном стиле
        
        Args:
            image_data (bytes): Исходная фотография
            style_prompt (str): Текстовое описание стиля
            
        Returns:
            bytes: Сгенерированный портрет или None, если ошибка
        """
        try:
            # Переводим описание стиля с русского на английский
            original_prompt = style_prompt
            translated_prompt = self.translate_with_deepl(style_prompt)
            logger.info(f"Translated style prompt: '{original_prompt}' -> '{translated_prompt}'")
            
            # Загружаем изображение
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for portrait generation")
                return None
            
            # Используем sketch2image API для генерации портрета
            data = {
                "imageUrl": image_url,
                "textPrompt": translated_prompt,
                "strength": 0.7  # Значение от 0 до 1, степень влияния текстового промпта
            }
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting portrait generation with style: {style_prompt}")
            response = requests.post(self.sketch2image_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request portrait generation: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from portrait generation API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id, max_retries=15, retry_interval=3)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download generated portrait: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error generating portrait: {e}")
            return None
            
    def ai_replace(self, image_data, text_prompt=None, mask_data=None):
        """
        Заменяет элемент на изображении с помощью текстового запроса (API Replace)
        
        Args:
            image_data (bytes): Исходная фотография
            text_prompt (str, optional): Текстовое описание для замены объекта
            mask_data (bytes, optional): Изображение маски (белый цвет для области замены)
            
        Returns:
            bytes: Обработанная фотография или None, если ошибка
        """
        # Проверка наличия API ключа LightX перед отправкой запроса
        if not self.api_key:
            logger.error("CRITICAL ERROR: LIGHTX_API_KEY не найден в переменных окружения!")
            logger.error("Убедитесь, что API ключ LightX добавлен в переменные окружения под именем LIGHTX_API_KEY")
            return None
            
        try:
            # Проверка обязательного параметра
            if not text_prompt or not text_prompt.strip():
                logger.error("Text prompt is required for AI Replace API")
                return None
            
            # Переводим текстовый запрос с русского на английский
            original_prompt = text_prompt
            translated_prompt = self.translate_with_deepl(text_prompt)
            logger.info(f"Translated AI Replace prompt: '{original_prompt}' -> '{translated_prompt}'")
                
            # Добавляем инструкции для сохранения черт лица
            preserve_instructions = "preserve exact facial features, do not change faces, maintain facial expression, keep face intact, only modify what is specified in the prompt, preserve personal identity"
            
            # Комбинируем основной запрос с инструкциями сохранения
            enhanced_prompt = f"{translated_prompt}, {preserve_instructions}"
            logger.info(f"Enhanced AI Replace prompt: {enhanced_prompt}")
            
            # Проверка наличия маски
            if not mask_data:
                logger.warning("Mask image is required for AI Replace API according to documentation")
                logger.warning("Generating a default mask (all white) for the image")
                
                try:
                    # Попытка создать простую белую маску с помощью PIL
                    from PIL import Image
                    import io
                    
                    # Создаем временный буфер и загружаем изображение
                    input_buffer = io.BytesIO(image_data)
                    with Image.open(input_buffer) as img:
                        width, height = img.size
                        # Создаем белую маску
                        mask = Image.new('L', (width, height), 255)
                        mask_buffer = io.BytesIO()
                        mask.save(mask_buffer, format='JPEG')
                        mask_buffer.seek(0)
                        mask_data = mask_buffer.read()
                        logger.info(f"Created default white mask with size {width}x{height}")
                except Exception as e:
                    logger.error(f"Failed to create default mask: {e}")
                    return None
                
            # Загружаем основное изображение
            logger.info(f"Uploading main image for AI Replace, size: {len(image_data)} bytes")
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload main image for AI Replace")
                return None
            
            # Загружаем маску (обязательный параметр)
            logger.info(f"Uploading mask image for AI Replace, size: {len(mask_data)} bytes")
            mask_url = self.upload_image(mask_data)
            if not mask_url:
                logger.error("Failed to upload mask image for AI Replace - mask is required")
                return None
            
            # Подготовка данных запроса
            data = {
                "imageUrl": image_url,
                "maskedImageUrl": mask_url,
                "textPrompt": enhanced_prompt.strip()  # Используем улучшенный промпт с инструкциями сохранения лица
            }
            
            # Подготовка заголовков
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправка запроса к API Replace
            logger.info(f"Sending request to AI Replace API with data: {json.dumps(data)}")
            response = requests.post(self.replace_url, headers=headers, json=data)
            
            # Вывод подробной информации о запросе для отладки
            logger.info(f"Request URL: {self.replace_url}")
            logger.info(f"Request Headers: {headers}")
            logger.info(f"Request Data: {data}")
            
            # Проверка статуса ответа
            if response.status_code != 200:
                logger.error(f"Failed to request AI Replace: {response.status_code} - {response.text}")
                return None
            
            # Анализ ответа
            result = response.json()
            logger.info(f"AI Replace API response: {result}")
            
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from AI Replace API: {result}")
                return None
            
            # Получение идентификатора заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in AI Replace API response")
                return None
            
            logger.info(f"AI Replace order created with ID: {order_id}")
            
            # Ожидание результата обработки
            output_url = self.wait_for_result(order_id, max_retries=10, retry_interval=2)
            if not output_url:
                logger.error(f"Failed to get result for order {order_id}")
                return None
            
            # Загрузка обработанного изображения
            logger.info(f"Downloading result image from: {output_url}")
            download_response = requests.get(output_url)
            
            if download_response.status_code != 200:
                logger.error(f"Failed to download AI Replace result: {download_response.status_code}")
                return None
            
            logger.info(f"Successfully completed AI Replace, result size: {len(download_response.content)} bytes")
            return download_response.content
            
        except Exception as e:
            logger.error(f"Error in AI Replace: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return None
            
    def change_emotions(self, image_data, emotion):
        """
        Изменяет выражение лица на фотографии
        
        Args:
            image_data (bytes): Исходная фотография
            emotion (str): Название эмоции (smile, sad, angry, etc.)
            
        Returns:
            bytes: Фотография с измененной эмоцией или None, если ошибка
        """
        try:
            # Переводим название эмоции с русского на английский
            original_emotion = emotion
            translated_emotion = self.translate_with_deepl(emotion)
            logger.info(f"Translated emotion: '{original_emotion}' -> '{translated_emotion}'")
            
            # Загружаем изображение
            image_url = self.upload_image(image_data)
            if not image_url:
                logger.error("Failed to upload image for emotion change")
                return None
                
            # Создаем запрос для изменения эмоций
            data = {
                "imageUrl": image_url,
                "emotion": translated_emotion
            }
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting emotion change to: {emotion}")
            response = requests.post(self.emotion_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request emotion change: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from emotion transfer API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download image with changed emotion: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error changing emotion: {e}")
            return None
            
    def generate_from_text(self, prompt, image_data=None):
        """
        Генерирует изображение по текстовому описанию
        
        Args:
            prompt (str): Текстовое описание для генерации
            image_data (bytes, optional): Опорное изображение или None
            
        Returns:
            bytes: Сгенерированное изображение или None, если ошибка
        """
        try:
            # Переводим текстовый запрос с русского на английский
            original_prompt = prompt
            translated_prompt = self.translate_with_deepl(prompt)
            logger.info(f"Translated text generation prompt: '{original_prompt}' -> '{translated_prompt}'")
            
            # Добавляем инструкции для качественного результата
            quality_instructions = "high quality, photorealistic, detailed texture, 4k resolution, perfect lighting"
            
            # Если запрос содержит фразы о человеке, добавляем инструкции для лица
            if any(word in original_prompt.lower() for word in ["человек", "портрет", "лицо"]) or \
               any(word in translated_prompt.lower() for word in ["person", "portrait", "face"]):
                face_instructions = "natural facial features, realistic face proportions, professional portrait quality"
                enhanced_prompt = f"{translated_prompt}, {face_instructions}, {quality_instructions}"
            else:
                enhanced_prompt = f"{translated_prompt}, {quality_instructions}"
            
            # Создаем запрос для генерации по тексту с улучшенным промптом
            data = {
                "textPrompt": enhanced_prompt,
                "negativePrompt": "low quality, blurry, distorted, bad anatomy, disfigured, ugly",
                "steps": 30,
                "width": 768,
                "height": 768
            }
            
            # Добавляем опорное изображение, если оно предоставлено
            if image_data:
                # Загружаем изображение
                image_url = self.upload_image(image_data)
                if image_url:
                    data["referenceImageUrl"] = image_url
                    data["referenceWeight"] = 0.5
            
            # Проверяем заголовки для аутентификации
            headers = {
                "Content-Type": "application/json",
                "x-api-key": self.api_key
            }
            
            # Отправляем запрос
            logger.info(f"Requesting text-to-image generation with original prompt: {prompt}")
            logger.info(f"Enhanced prompt with quality instructions: {enhanced_prompt}")
            response = requests.post(self.text2image_url, headers=headers, json=data)
            
            # Проверяем ответ
            if response.status_code != 200:
                logger.error(f"Failed to request text-to-image generation: {response.status_code} - {response.text}")
                return None
                
            # Анализируем ответ
            result = response.json()
            if result.get("statusCode") != 2000 or "body" not in result:
                logger.error(f"Invalid response from text-to-image API: {result}")
                return None
                
            # Получаем ID заказа
            order_id = result["body"].get("orderId")
            if not order_id:
                logger.error("Missing order ID in response")
                return None
                
            # Ждем результат
            output_url = self.wait_for_result(order_id, max_retries=15, retry_interval=3)
            if not output_url:
                return None
                
            # Загружаем результат
            response = requests.get(output_url)
            if response.status_code != 200:
                logger.error(f"Failed to download generated image: {response.status_code}")
                return None
                
            return response.content
            
        except Exception as e:
            logger.error(f"Error generating image from text: {e}")
            return None